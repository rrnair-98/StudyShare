import javax.media.*;
import java.io.*;
import java.net.*;
class PalyerDemo
{
	public static void main(String args[])
	{ try
		{
		Player p;
		p=Manager.createRealizedPlayer(new URL("C:\\Users\\Dhananjay\\Desktop\\MP3\\voice.mp3"));
		p.start();
		}catch(Exception e)
		{
			System.out.println("Exception \t"+e);
		}
	}
}