import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionListener;
import javax.swing.border.*;
import javax.swing.BorderFactory;
import java.awt.Image;
import java.awt.Toolkit;

 class CrimeReport extends JFrame 
{
	 CrimeReport()
	{
		setSize(650,700);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
		add(new SetupUI());
	

		setVisible(true);
	}
 public static void main(String args[])
	{
		new CrimeReport();
	}

}



 class SetupUI extends JPanel implements ActionListener
{
	JLabel lbl_blk1,lbl_blk2,lbl_blk3,lbl_blk4,lbl_blk5,lbl_blk6,lbl_blk7,lbl_blk8,lbl_blk9,lbl_blk10,lbl_blk11,lbl_blk12,lbl_blk13,lbl_blk14,lbl_blk15,lbl_blk16,lbl_blk17,lbl_blk18,lbl_blk19,lbl_blk20,lbl_blk21,lbl_blk22,welcome,icon,intro,intro1;
	
	JButton b1;
		
		public SetupUI()
		{
		//super("DirectX");
		setSize(650,700);
		setLayout(new GridLayout(9,3,5,5));
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		init();
		add();
		setVisible(true);
		}
	
		public void init()
		{
			
			lbl_blk1= new JLabel(" ");
			lbl_blk2= new JLabel(" ");
			lbl_blk3= new JLabel(" ");
			lbl_blk4= new JLabel(" ");
			lbl_blk5= new JLabel(" ");
			lbl_blk6= new JLabel(" ");
			lbl_blk7= new JLabel(" ");
			lbl_blk8= new JLabel(" ");
			lbl_blk9= new JLabel(" ");
			lbl_blk10= new JLabel(" ");
			lbl_blk11= new JLabel(" ");
			lbl_blk12= new JLabel(" ");
			lbl_blk13= new JLabel(" ");
			lbl_blk14= new JLabel(" ");
			lbl_blk15= new JLabel(" ");
			lbl_blk16= new JLabel(" ");
			lbl_blk17= new JLabel(" ");
			lbl_blk18= new JLabel(" ");
			lbl_blk19= new JLabel(" ");
			lbl_blk20= new JLabel(" ");
			lbl_blk21= new JLabel(" ");
			lbl_blk22= new JLabel(" ");
			
			icon= new JLabel();
			icon.setHorizontalAlignment(JLabel.CENTER);
			
			welcome= new JLabel("Welcome");
			welcome.setHorizontalAlignment(JLabel.CENTER);
			welcome.setFont(new Font("Calibri",Font.PLAIN,25));
			
			intro= new JLabel("Hi,");
			intro.setFont(new Font("Calibri",Font.PLAIN,20));
			intro.setHorizontalAlignment(JLabel.CENTER);
			
			intro1= new JLabel("You are here to generate your E-Bill");
			intro1.setFont(new Font("Calibri",Font.PLAIN,20));
			intro1.setHorizontalAlignment(JLabel.CENTER);
		
			
			 b1= new JButton("Get Started");
			 b1.setBackground(Color.GRAY);
			 b1.addActionListener(this);
	
			Image img= Toolkit.getDefaultToolkit().getImage("C:\\Users\\admin\\Desktop\\Shree\\new\\ico.png");
			ImageIcon newimg= new ImageIcon(img);
			icon.setIcon(newimg);
		}
		
		 public void add()
		 {
			add(lbl_blk1);
			add(icon);
			add(lbl_blk2);
			
			add(lbl_blk3);
			add(lbl_blk4);
			add(lbl_blk5);
			
			add(lbl_blk6);
			add(welcome);
			add(lbl_blk7);
			
			add(lbl_blk8);
			add(lbl_blk9);
			add(lbl_blk10);
			
			add(lbl_blk11);
			add(intro);
			add(lbl_blk12);
			
			add(lbl_blk21);
			add(intro1);
			add(lbl_blk22);
			
			add(lbl_blk13);
			add(lbl_blk14);
			add(lbl_blk15);
			
			add(lbl_blk16);
			add(b1);
			add(lbl_blk17);
			
			add(lbl_blk18);
			add(lbl_blk19);
			add(lbl_blk20);
		setVisible(true);
		}
	public void actionPerformed(ActionEvent ae)
	{
		
		Fir3 f= new Fir3();
	}

	
	public static void main(String args[])
	{
		new SetupUI();
	}
}



 class Fir3 extends JFrame implements ActionListener
{
	JLabel fir,name,add1,area,village,district,complaint,nature,loc,street,vill,doc,phone;
	JTextField n1,a1,v1,d1,c1,na1,l1,s1,v2,d2,p1;
	Border raisedlevel,loweredlevel,compound,grayline;
	JButton next;
	JPanel m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11,m12,m13,m14,m15,m16,m17,m18,m19,m20;
	//String str="";
		public Fir3()
		{
			setSize(650,700);
			setVisible(true);
			setTitle("Complaint Registration");
			setLayout(new BorderLayout());
			//setLookAndFeel();
			//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			initc();
			addc();
			
		
	
		}
			/*private void setLookAndFeel()
	{
		try
		{
			UIManager.setLookAndFeel(new SyntheticaBlackEyeLookAndFeel());
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null,"Some Issue in loading Look and Feel");
		}
	}*/
			public void initc()
			{
				m1=new JPanel();
				m2=new JPanel();
				m3=new JPanel();
				m4=new JPanel();
				m5=new JPanel();
				m6=new JPanel();
				m7=new JPanel();
				m8=new JPanel();
				m9=new JPanel();
				m10=new JPanel();
				
				m11=new JPanel();
				m12=new JPanel();
				m13=new JPanel();
				m14=new JPanel();
				m15=new JPanel();
				m16=new JPanel();
				m17=new JPanel();
				m18=new JPanel();
				m19=new JPanel();
				m20=new JPanel();
				
				raisedlevel=BorderFactory.createRaisedBevelBorder();
				loweredlevel=BorderFactory.createLoweredBevelBorder();

				
				fir=new JLabel("     COMPLAINT REGISTRATION");
				fir.setBorder(raisedlevel);
				name=new JLabel("     Name of Complainer:");
				name.setBorder(grayline);
				n1=new JTextField(20);
				area=new JLabel("     Area:");
				a1=new JTextField();
				village=new JLabel("     Village:");
				v1=new JTextField();
				phone=new JLabel("     Phone:");
				p1=new JTextField();
				
				
				district=new JLabel("     District:");
				d1=new JTextField(20);
				nature=new JLabel("     Nature of Complaint:");
				//cb=new JComboBox(case);
				na1=new JTextField(20);				
				street=new JLabel("     Street:");
				s1=new JTextField();
				vill=new JLabel("     Village:");
				v2=new JTextField();
				complaint=new JLabel("     Complaint:");
				c1=new JTextField();
				
				next = new JButton("NEXT");

				m1.setLayout(new GridLayout(3,3,10,10));
				m2.setLayout(new GridLayout(9,2,10,10));
				m3.setLayout(new GridLayout(1,2,10,10));
				m4.setLayout(new GridLayout(1,2,10,10));
				m5.setLayout(new GridLayout(1,2,10,10));
				m7.setLayout(new GridLayout(1,2,10,10));
				m8.setLayout(new GridLayout(1,2,10,10));
				
				m9.setLayout(new GridLayout(3,2,10,10));
				m10.setLayout(new GridLayout(1,2,10,10));
				m11.setLayout(new GridLayout(1,2,10,10));
				m12.setLayout(new GridLayout(1,2,10,10));
				m13.setLayout(new GridLayout(1,2,10,10));
				m14.setLayout(new GridLayout(1,2,10,10));
				m15.setLayout(new GridLayout(1,2,10,10));
				
				
				
				
				
				
				
				
				m6.setLayout(new GridLayout(3,1,10,10));
			}
				public void addc()
				{
					next.addActionListener(this);
					m1.add(fir);
					m1.add(new JLabel(""));
					m1.add(new JLabel(""));
					m1.add(new JLabel(""));
						m1.add(fir);
					m1.add(new JLabel(""));
					m1.add(new JLabel(""));
					m1.add(new JLabel(""));
					m1.add(new JLabel(""));
					m1.add(new JLabel(""));
					
					m3.add(name);
					m3.add(n1);
					m2.add(m3);
					
					m4.add(area);
					m4.add(a1);
					m2.add(m4);	
					
					
					m5.add(village);
					m5.add(v1);
					m2.add(m5);	
					
					m7.add(district);
					m7.add(d1);
					m2.add(m7);	
					
					m8.add(phone);
					m8.add(p1);
					m2.add(m8);	
					
					m10.add(nature);
					m10.add(na1);
					m2.add(m10);	
					
					m11.add(street);
					m11.add(s1);
					m2.add(m11);	
					
					m12.add(vill);
					m12.add(v2);
					m2.add(m12);	
					
					m13.add(complaint);
					m13.add(c1);
					m2.add(m13);	
					
					m6.add(new JLabel(""));
					m6.add(new JLabel(""));
					m6.add(next);
					add((m1),BorderLayout.NORTH);
					add((m2),BorderLayout.CENTER);
					//add((m9),BorderLayout.CENTER);
					add((m6),BorderLayout.SOUTH);
				}
					public void actionPerformed(ActionEvent ae)
					{
						if(n1.getText().equals("")||a1.getText().equals("")||v1.getText().equals("")||p1.getText().equals("")||d1.getText().equals("")||c1.getText().equals("")||na1.getText().equals("")||s1.getText().equals(""))
						{
							JOptionPane.showMessageDialog(this,"Please enter the blank field","Warning",JOptionPane.ERROR_MESSAGE);
						}
							else
							{
								Prr P= new Prr();
							}
					}
					/*public void actionPerformed(ActionEvent ae)
					{
						if(str.equals(""))
						{
							JOptionPane.showMessageDialog(this,"Please enter the blank field","Warning",JOptionPane.ERROR_MESSAGE);
						}
							else
							{
							}
					}*/
					
					
					
						public static void main(String args[])
						{
							Fir3 f1 = new Fir3();
						}
}



class Prr extends JFrame implements ItemListener,ActionListener
{	
	JLabel c1,l_2,c_I,l_3,l_4,l_5,l_6,c_id,l_7,l_8,l_9,l_10,l_11,l_12,l_13,l_14,l_15,l_16,action_l,l_17,l_18,l_19,l_20,l_21,l_22,l_23,l_24,l_25,l_26,l_29,l_30,l_31,l_32,l_33,l_34;
	JTextField t1,t2;
	JComboBox j1;
	JButton b1;
	JPanel p1,p2,p3;
	public Prr()
	{
	setSize(650,700);
	setBackground(Color.GRAY);

	//setLayout(new BorderLayout());
	
	initc();
	addc();
	getInsets();
	//itemStateChanged();
	setVisible(true);

	}
	public void initc()
	{
	Font f1=new Font("Calibiri",Font.BOLD,15);
	
	p1=new JPanel();
	p1.setLayout(new GridLayout(1,1));
	c1=new JLabel("  ");
	//l_27=new JLabel("  ");
	//l_28=new JLabel("  ");
	p2=new JPanel();
	p2.setLayout(new GridLayout(6,3));
	p2.setBackground(Color.DARK_GRAY);

	l_2=new JLabel(" ");
	c_I=new JLabel("COMPONENT INFORMATION");
	c_I.setFont(f1);
	c_I.setForeground(Color.WHITE);
	l_3=new JLabel(" ");
	l_4=new JLabel(" ");
	l_5=new JLabel(" ");
	l_6=new JLabel(" ");
	l_29=new JLabel(" ");
	l_30=new JLabel(" ");
	l_31=new JLabel(" ");
	//l_32=new JLabel(" ");
	//l_33=new JLabel(" ");
	//l_34=new JLabel(" ");
	c_id=new JLabel("                   Complaint Id   :-");
	c_id.setForeground(Color.WHITE);
	t1=new JTextField(30);
	t1.setBackground(Color.LIGHT_GRAY);
	t1.setForeground(Color.BLACK);
	l_7=new JLabel(" ");
	l_8=new JLabel(" ");
	l_9=new JLabel("Nature Of Compalint");
	l_9.setForeground(Color.WHITE);
	l_10=new JLabel(" ");
	l_11=new JLabel(" ");
	j1=new JComboBox();
	j1.addItem("Critical");
	j1.addItem("Catastorphic");
	j1.addItem("Average");
	j1.addItemListener(this);
	l_12=new JLabel(" ");
	p3=new JPanel();
	p3.setBackground(Color.DARK_GRAY);
	p3.setLayout(new GridLayout(6,3));
	l_13=new JLabel(" ");
	l_14=new JLabel(" ");
	l_15=new JLabel(" ");
	l_16=new JLabel(" ");
	action_l=new JLabel("Action Against Complaint");
	action_l.setForeground(Color.WHITE);
	l_17=new JLabel(" ");
	l_18=new JLabel(" ");
	t2=new JTextField(30);
	t2.setBackground(Color.LIGHT_GRAY);
	l_19=new JLabel(" ");
	l_20=new JLabel(" ");
	l_21=new JLabel(" ");
	l_22=new JLabel(" ");
	l_23=new JLabel(" ");
	b1=new JButton("NEXT");
	b1.addActionListener(this);
	l_24=new JLabel(" ");
	//p4=new JPanel();
	//p4.setLayout(new GridLayout(1,2));
	//l_25=new JLabel("      ");
	//l_26=new JLabel("      ");
	}
	public void addc()
	{
	p1.add(c1);
	//p1.add(l_27);
	//p1.add(l_28);
	p2.add(l_2);
	p2.add(c_I);
	p2.add(l_3);
	p2.add(l_4);
	p2.add(l_5);
	p2.add(l_6);
	p2.add(l_29);
	p2.add(l_30);
	p2.add(l_31);
	//p2.add(l_32);
	//p2.add(l_33);
	//p2.add(l_34);
	p2.add(c_id);
	p2.add(t1);
	p2.add(l_7);
	p2.add(l_8);
	p2.add(l_9);
	p2.add(l_10);
	p2.add(l_11);
	p2.add(j1);
	p2.add(l_12);
	p3.add(l_13);
	p3.add(l_14);
	p3.add(l_15);
	p3.add(l_16);
	p3.add(action_l);
	p3.add(l_17);
	p3.add(l_18);
	p3.add(t2);
	p3.add(l_19);
	p3.add(l_20);
	p3.add(l_21);
	p3.add(l_22);
	p3.add(l_23);
	p3.add(l_24);
	p3.add(b1);
	p3.add(new JLabel());
	p3.add(new JLabel());
	p3.add(new JLabel());
	//p4.add(l_25);
	//p4.add(l_26);
	add((p1),BorderLayout.NORTH);
	add((p2),BorderLayout.CENTER);
	add((p3),BorderLayout.SOUTH);
	//add((p4),BorderLayout.WEST);
	}
	public void itemStateChanged(ItemEvent ae)
	{
		repaint();
		if(j1.getSelectedItem()=="Critical")
		{
			p1.setBackground(Color.RED);
		}
		else if(j1.getSelectedItem()=="Catastorphic")
		{
			p1.setBackground(Color.GREEN);
		}
		else if(j1.getSelectedItem()=="Average")
		{
			p1.setBackground(Color.YELLOW);
		}
	}
	public void actionPerformed(ActionEvent ae)
	{
			Report r= new Report();	
	}
		
	
	public Insets getInsets()
	{
		return new Insets(50,50,50,50);
	}

	public static void main(String args[])
	{
	new Prr();
	}
}






class Report extends JFrame
{
	JPanel pnl_north,pnl_center,pnl_center_top,pnl_center_bottom,pnl_south,pnl_east,pnl_west,pnl_south_top,pnl_south_bottom,pnl_south_bottom_east,pnl_south_bottom_west,pnl_south_last;
	JLabel lbl_report,lbl_name,lbl_address,lbl_phone,lbl_complaintid,lbl_personal,lbl_complaint,lbl_action,lbl_data;
	JButton back,save;

	public Report()
	{
	
	setSize(650,760);
	setLayout(new BorderLayout());
	init();
	set();
	add();
	
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setVisible(true);
	}
	
	public void init()
	{
		pnl_north= new JPanel();
		
		lbl_report= new JLabel("Report");
		
		pnl_center= new JPanel();

		pnl_center_top= new JPanel();
		lbl_personal= new JLabel("Personal Info");
		
		pnl_center_bottom= new JPanel();
		lbl_name= new JLabel("Name:");
		lbl_address= new JLabel("Address:");
		lbl_phone= new JLabel("Phone no.");
		lbl_complaintid= new JLabel("Complaint ID:");
		
		
		pnl_east= new JPanel();
		pnl_west= new JPanel();
		
		pnl_south= new JPanel();
		
		//lbl_complaintid= new JLabel("Complaint ID:");
		lbl_action= new JLabel("Action Against Complaint:");
		
		pnl_south_top= new JPanel();

		pnl_south_bottom= new JPanel();
		lbl_data= new JLabel("The Complaint was registered and FIR was made,further inquiry will be carried.");
		
		pnl_south_bottom_east= new JPanel();

		pnl_south_bottom_west= new JPanel();

		pnl_south_last= new JPanel();

		back= new JButton("< Back");
		save= new JButton("Save");
	}

	
	public void set()
	{
		pnl_north.setLayout(new GridLayout(1,3));
		
		lbl_report.setFont(new Font("Calibri",Font.BOLD,35));
		lbl_report.setHorizontalAlignment(JLabel.CENTER);
		lbl_report.setVerticalAlignment(JLabel.CENTER);
		lbl_report.setOpaque(true);
		lbl_report.setForeground(Color.LIGHT_GRAY);
		lbl_report.setBackground(Color.GRAY);
		
		
		pnl_center_top.setLayout(new GridLayout(1,3));
		pnl_center_bottom.setLayout(new GridLayout(4,4,35,35));
		lbl_name.setFont(new Font("Calibri",Font.PLAIN,20));
		lbl_name.setHorizontalAlignment(JLabel.CENTER);
		//lbl_name.setOpaque(true);
		//lbl_name.setForeground(Color.GRAY);
		
		lbl_address.setFont(new Font("Calibri",Font.PLAIN,20));
		lbl_address.setHorizontalAlignment(JLabel.CENTER);
		//lbl_address.setForeground(Color.GRAY);

		lbl_phone.setFont(new Font("Calibri",Font.PLAIN,20));
		lbl_phone.setHorizontalAlignment(JLabel.CENTER);

		lbl_complaintid.setFont(new Font("Calibri",Font.PLAIN,20));
		lbl_complaintid.setHorizontalAlignment(JLabel.CENTER);

		lbl_personal.setFont(new Font("Calibri",Font.BOLD,25));
		lbl_personal.setHorizontalAlignment(JLabel.CENTER);

		pnl_center.setLayout(new GridLayout(3,1));

		pnl_east.setBackground(Color.GRAY);
		pnl_west.setBackground(Color.GRAY);
	
		pnl_south.setLayout(new GridLayout(3,1,5,5));
		pnl_south.setBackground(Color.GRAY);
	
		lbl_action.setFont(new Font("Calibri",Font.BOLD,19));
		lbl_action.setVerticalAlignment(JLabel.TOP);
		pnl_south_top.setLayout(new GridLayout(1,3,2,2));
	
		pnl_south_bottom.setLayout(new BorderLayout());
		pnl_south_bottom.setBackground(Color.LIGHT_GRAY);

		pnl_south_last.setLayout(new GridLayout(2,4));

		back.setBackground(Color.GRAY);
		save.setBackground(Color.GRAY);
		
	}
	
	public void add()
	{
		pnl_north.add(new JLabel());
		pnl_north.add(lbl_report);
		pnl_north.add(new JLabel());
		
		add((pnl_north),BorderLayout.NORTH);
	
		
		
		pnl_center_top.add(new JLabel());
		pnl_center_top.add(lbl_personal);
		pnl_center_top.add(new JLabel());
		
	
		pnl_center_bottom.add(new JLabel());
		pnl_center_bottom.add(lbl_name);
		pnl_center_bottom.add(new JLabel("Suraj Kakad"));
		pnl_center_bottom.add(new JLabel());
	
		pnl_center_bottom.add(new JLabel());
		pnl_center_bottom.add(lbl_address);
		pnl_center_bottom.add(new JLabel("Worli Police Camp,sir poachkhanwala road,worli,mumbai-400030"));
		pnl_center_bottom.add(new JLabel());

		pnl_center_bottom.add(new JLabel());
		pnl_center_bottom.add(lbl_phone);
		pnl_center_bottom.add(new JLabel("9699493820"));
		pnl_center_bottom.add(new JLabel());

		pnl_center_bottom.add(new JLabel());
		pnl_center_bottom.add(lbl_complaintid);
		pnl_center_bottom.add(new JLabel("COM-120"));
		pnl_center_bottom.add(new JLabel());
		
		pnl_center.add(pnl_center_top);
		pnl_center.add(pnl_center_bottom);

		add((pnl_center),BorderLayout.CENTER);
		
		pnl_south_top.add(new JLabel());
		pnl_south_top.add(lbl_action);
		pnl_south_top.add(new JLabel());
		

		pnl_south_bottom_east.add(new JLabel("   "));
		pnl_south_bottom_east.add(new JLabel("   "));
		pnl_south_bottom_east.add(new JLabel("   "));
		pnl_south_bottom_east.add(new JLabel("   "));

		pnl_south_bottom_west.add(new JLabel("   "));
		pnl_south_bottom_west.add(new JLabel("   "));
		pnl_south_bottom_west.add(new JLabel("   "));
		pnl_south_bottom_west.add(new JLabel("   "));

		pnl_south_bottom.add((lbl_data),BorderLayout.CENTER);
		pnl_south_bottom.add((pnl_south_bottom_east),BorderLayout.EAST);
		pnl_south_bottom.add((pnl_south_bottom_west),BorderLayout.WEST);

		pnl_south_last.add(new JLabel());
		pnl_south_last.add(new JLabel());
		pnl_south_last.add(new JLabel());
		pnl_south_last.add(new JLabel());
		
		pnl_south_last.add(back);
		pnl_south_last.add(new JLabel());
		pnl_south_last.add(new JLabel());
		pnl_south_last.add(save);

	

		pnl_south.add(pnl_south_top);
		pnl_south.add(pnl_south_bottom);
		pnl_south.add(pnl_south_last);

		
		add((pnl_south),BorderLayout.SOUTH);
		
		add((pnl_east),BorderLayout.EAST);
		add((pnl_west),BorderLayout.WEST);
	}
	

	public static void main(String args[])
	{
		new Report();
	}
}