import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.awt.image.*;
import javax.imageio.*;
import javax.swing.*;
class RobotDemo extends Frame
{
	boolean on;
	Rectangle rect;
	String path;
	Robot r;
	BufferedImage bi;
	int i;
	Button start,end;
	Thread t;
	RobotDemo()
	{
		start=new Button("START");
		start.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				new MyThread();		
				/*try
				{
					i=0;
					on=true;
					rect=new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
					path="ScreenShot//ScreenShot";
					r=new Robot();
					while(on)
					{
						System.out.println(SwingUtilities.isEventDispatchThread());
						Thread.sleep(1000);
						bi=r.createScreenCapture(rect);
						ImageIO.write(bi,"jpg",new File(path+i+".jpg"));
						i++;
					}
				}
				catch (Exception e)
				{
					System.out.println(e);
				}*/
			}
		});
		end=new Button("END");
		end.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				System.exit(0);
			}
		});
		add(start,BorderLayout.EAST);
		add(end,BorderLayout.WEST);
		setSize(100,100);
		setVisible(true);
	}
	public static void main(String[] args) 
	{
		new RobotDemo();
	}
}
class MyThread extends Thread
{
	Rectangle rect;
	String path;
	Robot r;
	BufferedImage bi;
	int i;
	MyThread()
	{
		start();
	}
	public void run()
	{
		try
		{
			i=0;
			rect=new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
			path="ScreenShot//ScreenShot";
			r=new Robot();
			while(true)
			{
				Thread.sleep(10);
				bi=r.createScreenCapture(rect);
				ImageIO.write(bi,"png",new File(path+i+".png"));
				i++;
			}
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}
}