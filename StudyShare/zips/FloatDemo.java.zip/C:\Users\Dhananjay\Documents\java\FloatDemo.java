class FloatDemo
{
	static double f;
	static String s="11";
	public static void main(String args[])
	{
		try 
		{
			f=Double.parseDouble(s);
			System.out.println(f);
		}
		catch(Exception e){}
	}
}