import javax.swing.*;
//import javax.swing.plaf.*;
//import javax.swing.plaf.metal;
//import java.awt.*;

class Notepad extends JFrame 
{
	JMenuBar mbr;
	JMenu file,edit,format,view,help;
	Notepad()
	{
		super("Hardwell");
		setSize(500,500);
		//setLayout(new FlowLayout());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		mbr= new JMenuBar();
		setJMenuBar(mbr);

		file= new JMenu("File");
		JMenuItem m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11,m12,m13,m14,m15,m16,m17,m18,m20,m22,m23;
		JCheckBoxMenuItem m19,m21;
		//MenuShortcut s1;
		file.add(m1= new JMenuItem("New       Ctrl+N"));
		file.add(m2= new JMenuItem("Open...   Ctrl+O"));
		file.add(m3= new JMenuItem("Save      Ctrl+S"));
		file.add(m4= new JMenuItem("Save As..."));
		file.addSeparator();
		file.add(m5= new JMenuItem("Page Setup..."));
		file.add(m6= new JMenuItem("Print     Ctrl+P"));
		file.addSeparator();
		file.add(m7= new JMenuItem("Exit"));
		

		mbr.add(file);

		edit= new JMenu("Edit");

		edit.add(m8= new JMenuItem("Undo          Ctrl+Z"));
		edit.addSeparator();
		edit.add(m9= new JMenuItem("Cut           Ctrl+X"));
		edit.add(m10= new JMenuItem("Copy         Ctrl+C"));
		edit.add(m11= new JMenuItem("Paste        Ctrl+V"));
		edit.add(m12= new JMenuItem("Delete          Del"));
		edit.addSeparator();
		edit.add(m13= new JMenuItem("Find...      Ctrl+F"));
		edit.add(m14= new JMenuItem("Find Next        F3"));
		edit.add(m15= new JMenuItem("Replace...   Ctrl+H"));
		edit.add(m16= new JMenuItem("Go To...     Ctrl+G"));
		edit.addSeparator();
		edit.add(m17= new JMenuItem("Select All   Ctrl+A"));
		edit.add(m18= new JMenuItem("Time/Date        F5"));
		

		mbr.add(edit);

		format= new JMenu("Format");

		format.add(m19= new JCheckBoxMenuItem("Word Wrap"));
		format.add(m20= new JMenuItem("Font..."));

		mbr.add(format);

		view= new JMenu("View");

		view.add(m21= new JCheckBoxMenuItem("Status Bar"));

		mbr.add(view);

		help= new JMenu("Help");

		help.add(m22= new JMenuItem("View Help"));
		help.addSeparator();
		help.add(m23= new JMenuItem("About Notepad"));

		mbr.add(help);
		/*m1.addActionListener(this);
		m2.addActionListener(this);
		m3.addActionListener(this);
		m4.addActionListener(this);
		m5.addActionListener(this);
		m6.addActionListener(this);
		m7.addActionListener(this);*/
	
		add(new JTextArea());
		setVisible(true);
	}

	public static void main(String args[])
	{
		 new Notepad();
	}
}