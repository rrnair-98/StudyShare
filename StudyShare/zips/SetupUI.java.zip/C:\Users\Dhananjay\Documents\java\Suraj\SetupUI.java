import javax.swing.*;
import java.awt.*;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.*;

public class SetupUI extends JFrame
{
	JLabel lbl_blk1,lbl_blk2,lbl_blk3,lbl_blk4,lbl_blk5,lbl_blk6,lbl_blk7,lbl_blk8,lbl_blk9,lbl_blk10,lbl_blk11,lbl_blk12,lbl_blk13,lbl_blk14,lbl_blk15,lbl_blk16,lbl_blk17,lbl_blk18,lbl_blk19,lbl_blk20,lbl_blk21,lbl_blk22,welcome,icon,intro,intro1;
	
	JButton b1;
		
		public SetupUI()
		{
		super("DirectX");
		setSize(500,500);
		setLayout(new GridLayout(9,3,5,5));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		init();
		add();
		setVisible(true);
		}
	
		public void init()
		{
			
			lbl_blk1= new JLabel(" ");
			lbl_blk2= new JLabel(" ");
			lbl_blk3= new JLabel(" ");
			lbl_blk4= new JLabel(" ");
			lbl_blk5= new JLabel(" ");
			lbl_blk6= new JLabel(" ");
			lbl_blk7= new JLabel(" ");
			lbl_blk8= new JLabel(" ");
			lbl_blk9= new JLabel(" ");
			lbl_blk10= new JLabel(" ");
			lbl_blk11= new JLabel(" ");
			lbl_blk12= new JLabel(" ");
			lbl_blk13= new JLabel(" ");
			lbl_blk14= new JLabel(" ");
			lbl_blk15= new JLabel(" ");
			lbl_blk16= new JLabel(" ");
			lbl_blk17= new JLabel(" ");
			lbl_blk18= new JLabel(" ");
			lbl_blk19= new JLabel(" ");
			lbl_blk20= new JLabel(" ");
			lbl_blk21= new JLabel(" ");
			lbl_blk22= new JLabel(" ");
			
			icon= new JLabel();
			icon.setHorizontalAlignment(JLabel.CENTER);
			
			welcome= new JLabel("Welcome");
			welcome.setHorizontalAlignment(JLabel.CENTER);
			welcome.setFont(new Font("Calibri",Font.PLAIN,25));
			
			intro= new JLabel("Hi,");
			intro.setFont(new Font("Calibri",Font.PLAIN,20));
			intro.setHorizontalAlignment(JLabel.CENTER);
			
			intro1= new JLabel("You are here to generate your E-Bill");
			intro1.setFont(new Font("Calibri",Font.PLAIN,20));
			intro1.setHorizontalAlignment(JLabel.CENTER);
		
			
			 b1= new JButton("Get Started");
	
			Image img= Toolkit.getDefaultToolkit().getImage("C:\\Users\\admin\\Desktop\\Shree\\new\\ico.png");
			ImageIcon newimg= new ImageIcon(img);
			icon.setIcon(newimg);
		}
		
		 public void add()
		 {
			add(lbl_blk1);
			add(icon);
			add(lbl_blk2);
			
			add(lbl_blk3);
			add(lbl_blk4);
			add(lbl_blk5);
			
			add(lbl_blk6);
			add(welcome);
			add(lbl_blk7);
			
			add(lbl_blk8);
			add(lbl_blk9);
			add(lbl_blk10);
			
			add(lbl_blk11);
			add(intro);
			add(lbl_blk12);
			
			add(lbl_blk21);
			add(intro1);
			add(lbl_blk22);
			
			add(lbl_blk13);
			add(lbl_blk14);
			add(lbl_blk15);
			
			add(lbl_blk16);
			add(b1);
			add(lbl_blk17);
			
			add(lbl_blk18);
			add(lbl_blk19);
			add(lbl_blk20);
		setVisible(true);
		}
	
	public static void main(String args[])
	{
		new SetupUI();
	}
}