import java.io.*;
import org.apache.poi.xssf.usermodel.*;
 class CreateWorkBook 
{
   public static void main(String[] args)throws Exception 
   {
      //Create Blank workbook
      XSSFWorkbook workbook = new XSSFWorkbook(new File("Dhananjay1.xlsx")); 
      //Create file system using specific name
	  
      //FileOutputStream out = new FileOutputStream(new File("Dhananjay.xlsx"));
      //write operation workbook using file out object
      //workbook.write();
      //out.close();
      System.out.println(" createworkbook.xlsx written successfully");
   }
}