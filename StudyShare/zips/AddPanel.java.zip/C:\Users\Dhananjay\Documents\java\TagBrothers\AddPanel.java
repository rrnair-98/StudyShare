package TagBrothers;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import TagBrothers.controls.*;

public class AddPanel extends JPanel
{
	String stylish_Name_Arr[]={"Akshay","Ram","Sham","Alex"};
	String work_Type_Arr[]={"Hair-cut","Hair-cut with wash","Shaving"};
	JLabel lbl_Name,lbl_Number,lbl_Stylish,lbl_Work;
	ValidatedTextField txt_Name;
	NumericTextField txt_Number;
	JComboBox stylish_Name;
	JList work_Type;
	JButton btn_Add;
	CustomerScrollPane customerQueue;
	
	AddPanel(CustomerScrollPane ref)
	{
		customerQueue=ref;
		setLayout(new GridLayout(5,2));
		initializeAll();
		addAll();
	}
	
	void initializeAll()
	{
		lbl_Name=new JLabel("Name");
		lbl_Number=new JLabel("Number");
		lbl_Stylish=new JLabel("Stylish");
		lbl_Work=new JLabel("Work");
		
		txt_Name=new ValidatedTextField(){
			public boolean validateTextField()
			{
				if(getText().length()==0)
					return false;
				else
					return true;
			}
		};
		txt_Number=new NumericTextField(10);
		
		stylish_Name=new JComboBox(stylish_Name_Arr);
		
		work_Type=new JList(work_Type_Arr);
		work_Type.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		
		btn_Add=new JButton("ADD");
		btn_Add.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				addCustomerToQueue();
			}
		});
	}
	
	void addAll()
	{
		add(lbl_Name);
		add(txt_Name);
		

		
		add(lbl_Number);
		add(txt_Number);
		
		
		
		add(lbl_Stylish);
		
		add(stylish_Name);
		
		
		
		
		add(lbl_Work);
		add(work_Type);
		
		add(btn_Add);
	}
	
	void addCustomerToQueue()
	{
		JButton cus=new JButton(txt_Name.getText().charAt(txt_Name.getText().indexOf(" ")+1)+"."+txt_Name.getText().substring(0,txt_Name.getText().indexOf(" ")));
		System.out.println(txt_Name.getText().charAt(txt_Name.getText().indexOf(" ")+1)+"."+txt_Name.getText().substring(0,txt_Name.getText().indexOf(" ")));
		customerQueue.innerPanel.add(cus);
	}
	
	public Insets getInsets()
	{
		return new Insets(5,5,5,5);
	}
}