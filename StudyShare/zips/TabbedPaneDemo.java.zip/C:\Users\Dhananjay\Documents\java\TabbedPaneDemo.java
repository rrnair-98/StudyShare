import java.awt.*;
import javax.swing.*;
class TabbedPaneDemo extends JFrame 
{
	JButton b,c;
	JTabbedPane jp;
	TabbedPaneDemo()
	{
		jp=new JTabbedPane(SwingConstants.TOP,JTabbedPane.WRAP_TAB_LAYOUT);
		jp.add(new Button("TOP"),BorderLayout.NORTH);
		jp.add("Button",new JButton("JIANAM"));
		jp.add("Button",c=new JButton("PRATIK"));
		jp.add("Button",new JButton("Dhananjay"));
		jp.add("Button",b=new JButton("Nikhil"));
		add(jp);
		setSize(300,300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		System.out.println("Hello");
		try
		{
			Thread.sleep(1000);
		}
		catch (Exception e)
		{
		}
		jp.setSelectedComponent(b);
		try
		{
			Thread.sleep(500);
		}
		catch (Exception e)
		{
		}
		jp.setSelectedComponent(c);
		jp.setDisabledIconAt(1,null);
	}
	public static void main(String[] args) 
	{
		new TabbedPaneDemo();
	}
}
