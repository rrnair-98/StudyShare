import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.datatransfer.*;

class MyClipboard implements ClipboardOwner
{
	Toolkit tk;  
	JButton hack;
	Clipboard cp;
	StringSelection ss;
	Thread t;
	MyClipboard()
	{
		hackIt();
		t=new Thread()
		{
			public void run()
			{
				while(true);
			}
		};
		t.start();
	}
	public static void main(String args[])
	{
		new MyClipboard();
	}
	void hackIt()
	{
		tk=Toolkit.getDefaultToolkit();
		cp=tk.getSystemClipboard();
		ss=new StringSelection("CAN'T PASTE HERE");
		cp.setContents(ss,this);
		System.out.println("Hacked");	
	}
	public void lostOwnership(Clipboard clipboard,Transferable contents)
	{
		hackIt();
	}
}