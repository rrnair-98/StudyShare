import java.awt.*;
import java.awt.event.*;
class Pre extends Frame
{
	Pre()
	{
		setSize(500,500);
		
		Button b=new Button("CLOSE");
		add(b);
		setVisible(true);
		Dialog d=new Dialog(this,"Dhananjay",true);
			
		d.setSize(200,200);
		d.add(b);
		b.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				d.dispose();
			}
		});
	
	d.setVisible(true);
		
	}
	public static void main(String args[])
	{
		new Pre();
	}
}