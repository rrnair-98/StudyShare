import java.util.Vector;
import javax.media.*;
import javax.media.format.AudioFormat;
import javax.media.format.VideoFormat;
import javax.media.protocol.DataSource;
import javax.media.CaptureDeviceInfo;
import javax.media.format.YUVFormat;
import javax.media.protocol.FileTypeDescriptor;

public class VoiceRecorder {

    static AudioFormat audioFormat;
    static CaptureDeviceInfo audioDevice;

    public static void main(String[] args) 
	{
		try {
        Vector deviceList = CaptureDeviceManager.getDeviceList(new AudioFormat(AudioFormat.LINEAR));
		System.out.println(deviceList.size());
		audioDevice=(CaptureDeviceInfo)deviceList.firstElement();
		audioFormat=new AudioFormat(AudioFormat.LINEAR);
		System.out.println(audioDevice.getName());
       
	   {
		   System.out.println("formats supported :");
		   Format form[]=audioDevice.getFormats();
		   for(int i=0;i<form.length;i++)
		   {
				System.out.println(form[i]);
		   }
	   }
        //create data sources
        DataSource audioDataSource = Manager.createDataSource(audioDevice.getLocator());

      System.out.println(audioDataSource);

            Format [] fm=new Format[1];
			fm[0]=new AudioFormat(AudioFormat.LINEAR);

        //output type
            FileTypeDescriptor outputType=new FileTypeDescriptor(FileTypeDescriptor.MPEG_AUDIO);

        //settingup Processor
            ProcessorModel processorModel=new ProcessorModel(audioDataSource,fm,outputType);
            Processor processor=Manager.createRealizedProcessor(processorModel);
			System.out.println("Hello");

        //settingup sink
            DataSource outputDataSource=processor.getDataOutput();
            MediaLocator destination=new MediaLocator("file:.\\voiceDemo.mpg");
            DataSink dataSink=Manager.createDataSink(outputDataSource, destination);
            dataSink.open();
			
            //start sink + processor
            dataSink.start();
            processor.start();
			System.out.println("Start speaking");

            Thread.sleep(4000);

            dataSink.close();
            processor.stop();
            processor.close();

    } catch (Exception ex) {
        System.out.println(ex);

    }
	}
}