import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;
class JFileChooserDemo extends JFrame
{
	File
	File f;
	String name;
	String path;
	JTextField my;
	JButton save,open;
	JFileChooser jc;
	JFileChooserDemo()
	{
		my=new JTextField();
		jc=new JFileChooser();
		save=new JButton("SAVE");
		open=new JButton("OPEN");
		setLayout(new FlowLayout());
		add(save);
		add(open);
		add(my);
		save.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				jc.showSaveDialog(JFileChooserDemo.this);
				//name=jc.getName(jc.getSelectedFile());
				path=jc.getSelectedFile().getPath();
				try
				{
					f=new File(path);
					f.createNewFile();	
				}
				catch (Exception e)
				{
				}

			}
		});
		open.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				jc.showOpenDialog(JFileChooserDemo.this);
				System.out.println(jc.getName(jc.getSelectedFile()));
			}
		});
		jc=new JFileChooser();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(100,100);
		setVisible(true);
	}
	public static void main(String args[])
	{
		new JFileChooserDemo();
	}
}