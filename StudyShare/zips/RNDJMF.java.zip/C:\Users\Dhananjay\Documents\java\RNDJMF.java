import javax.media.*;
import javax.media.format.*;
import java.util.*;
class RNDJMF
{
	Vector v;
	Enumeration e;
	CaptureDeviceInfo f;
	
	RNDJMF()
	{
		//f=CaptureDeviceManager.getDevice("Integrated Webcam");
		//System.out.println(f);
		v=CaptureDeviceManager.getDeviceList(null);
		e=v.elements();
		while(e.hasMoreElements())
			System.out.println(e.nextElement());
		System.out.println("Hello");
	}
	
	public static void main(String args[])
	{
		new RNDJMF();
	}
}