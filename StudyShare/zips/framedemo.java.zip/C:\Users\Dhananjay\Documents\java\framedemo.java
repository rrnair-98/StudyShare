import java.awt.*;
import java.awt.event.*;

class FrameDemo extends Frame implements ActionListener
{
	String msg="";

	FrameDemo()
	{
		super("MyFrame");
		setVisible(true);
		setLayout(new FlowLayout());
		Button b1= new Button("Suraj");
		Button b2= new Button("Kaustubh");
		Button b3= new Button("Dhananjay");
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		addWindowListener(new MyAdapter(this));
		add(b1);
		add(b2);
		add(b3);
		setSize(400,400);
	}

	public void actionPerformed(ActionEvent ae)
	{
			
			String str= ae.getActionCommand();
			if(str.equals("Suraj"))
			{
				msg="Kakad";
			}
			else if(str.equals("Kaustubh"))
			{
				msg="Naik";
			}
			else {
					msg="Ghumare";			
				}
			repaint();
	}

	public void paint(Graphics g)
	{
		g.drawString(msg, 100,100);
	}

	
	public static void main(String args[])
	{
		FrameDemo f2= new FrameDemo();
	}
}

class MyAdapter extends WindowAdapter
{
	FrameDemo f;
	MyAdapter(FrameDemo ref)
	{
		f=ref;
	}
	public void windowClosing(WindowEvent we)
	{
		f.dispose();
	}
}