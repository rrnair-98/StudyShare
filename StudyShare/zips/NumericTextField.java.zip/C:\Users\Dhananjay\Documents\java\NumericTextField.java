import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class NumericTextField extends JTextField 
{
	NumericTextField(int count,String placeHolder)
	{
		super(50);
		setText(placeHolder);
		setForeground(Color.LIGHT_GRAY);
		addKeyListener(new KeyAdapter()
		{
			public void keyTyped(KeyEvent ke)
			{
					char ch=ke.getKeyChar();
					if(!(Character.isDigit(ch)&&getText().length()<count))
						ke.consume();
			}
		});
		
		addFocusListener(new FocusAdapter()
		{
			public void focusGained(FocusEvent fe)
			{
				if(getText().equals(placeHolder))
				{
					setForeground(Color.BLACK);
					setText("");
				}
			}
			
			public void focusLost(FocusEvent fe)
			{
				if(getText().equals(""))
				{
					setForeground(Color.LIGHT_GRAY);
					setText(placeHolder);
				}
			}
		});
	}
}

class NumericDemo extends JFrame
{
	NumericTextField textField;
	JTextField jtf;
	NumericDemo()
	{
		jtf=new JTextField("hello");
		textField=new NumericTextField(10,"Only NUMBERS");
		setLayout(new FlowLayout());
		add(jtf);
		add(textField);
		setSize(100,100);
		setVisible(true);
	}
	
	public static void main(String args[])
	{
		new NumericDemo();
	}
}