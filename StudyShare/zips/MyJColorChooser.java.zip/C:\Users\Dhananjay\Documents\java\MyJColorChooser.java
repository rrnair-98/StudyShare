import java.awt.*;
import javax.swing.*;
import java.awt.datatransfer.*;

class MyJColorChooser extends JFrame
{
	StringSelection ss;
	Clipboard cb;
	Frame f;
	JColorChooser j;
	Color c;

	MyJColorChooser()
	{
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cb=Toolkit.getDefaultToolkit().getSystemClipboard();
		f=new Frame();
		j=new JColorChooser();
		showD();
	}

	public static void main(String args[])
	{
		new MyJColorChooser();
	}

	void showD()
	{
		while(true)
		{
			c=j.showDialog(f,"COLOR",null);
			ss=new StringSelection(c.getRed()+","+c.getGreen()+","+c.getBlue());
			cb.setContents(ss,ss);
		}
	}
}