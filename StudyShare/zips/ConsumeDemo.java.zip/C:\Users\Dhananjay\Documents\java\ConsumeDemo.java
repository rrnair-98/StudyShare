import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;

public class ConsumeDemo 
{
	JFrame j=new JFrame();
	TextField jb;
	ConsumeDemo()
	{
		j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jb=new TextField();
		jb.addTextListener(new TextListener()
		{
			public void textValueChanged(TextEvent ie)
			{
				consume();
				System.out.println("Hello");
			}
		});
		j.add(jb);
		j.setVisible(true);
		//jb.addItem(new MenuItem("Dahnanaj"));
		//jb.addItem(new MenuItem("sdsa"));
		//j/b.addItem(new MenuItem("Dahnasdanaj"));
	}
	public static void main(String[] args) 
	{
		new ConsumeDemo();
	}
}
/*class TpEvent extends AWTEvent
{
	TpEvent(ItemEvent ie){
		ie.
		
	}public void callConsume(){
		consume();
	}

}*/
