import java.util.*;
class CalendarDemo
{
	GregorianCalendar gc;

	CalendarDemo()
	{
		gc=new GregorianCalendar(2017,11,1);
		System.out.println(gc.get(GregorianCalendar.DAY_OF_WEEK));
	}
	public static void main(String args[])
	{
		new CalendarDemo();
	}
}