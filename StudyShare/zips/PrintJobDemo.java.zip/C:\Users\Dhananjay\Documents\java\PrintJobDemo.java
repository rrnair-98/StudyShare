import java.awt.*;
import java.awt.print.*;

class PrintJobDemo
{
	PrinterJob printer;
	boolean flag;
	PrintJobDemo()
	{
		printer=PrinterJob.getPrinterJob();
		printer.setPrintable(new MyPrintable());
		flag=printer.printDialog();
		try
		{
			if(flag)
			printer.print();	
		}
		catch (Exception e)
		{
		}
		
	}

	public static void main(String args[]) throws Exception
	{
		new PrintJobDemo();
	}
}

class MyPrintable implements Printable
{
	public int print(Graphics g,PageFormat pf,int index)
	{
		if(index>0)
			return NO_SUCH_PAGE;
		
		Graphics2D g2d=(Graphics2D)g;
		g2d.translate(pf.getImageableX(),pf.getImageableY());
		g.drawString("Dhananjay",100,100);

		return PAGE_EXISTS;
	}
}