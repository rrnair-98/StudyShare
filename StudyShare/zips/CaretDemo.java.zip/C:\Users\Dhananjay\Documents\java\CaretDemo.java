 import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

class CaretDemo extends JFrame 
{
	JTextField tf;

	CaretDemo()
	{
		tf=new JTextField();
		tf.addCaretListener(new Vidhi());
		add(tf);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(500,500);
		setVisible(true);
	}

	public static void main(String args[])
	{
		new CaretDemo();
	}

}

class Vidhi implements CaretListener
{
	public void caretUpdate(CaretEvent ce)
	{
		System.out.println("Caret Updated");
	}
}