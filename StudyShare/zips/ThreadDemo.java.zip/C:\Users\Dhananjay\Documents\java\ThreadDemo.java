class ThreadDemo extends Class
{
	public static void main(String[] args) 
	{
		new GUIThread();
	}
}
class GUIThread extends Thread
{
	GUIThread()
	{
		start();
	}
	public void run()
	{
		new EventThread();
		System.out.println("You are wrongS");
	}
}
class EventThread extends Thread
{
	EventThread()
	{
		start();
	}
	public void run()
	{
		while(true)
		{
		}
	}
}
