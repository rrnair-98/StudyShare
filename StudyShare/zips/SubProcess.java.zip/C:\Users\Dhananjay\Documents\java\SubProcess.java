import javax.swing.*;


class SubProcess{
	public static void main(String args[]){
		System.out.println("Hello Parent Process");
		JFrame frame=new JFrame();
		System.err.write(91);
		frame.setSize(100,100);
		frame.setVisible(true);
	}
}