import java.net.*;
import java.io.*;
class MyClient
{
	public static void main(String args[])
	{
		try(Socket client=new Socket(new String(""),4444))
		{
			int by;
			byte arr[]=new byte[100];
			InputStream in=client.getInputStream();
			OutputStream out=client.getOutputStream();
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			while(true)
			{
			String s=new String(br.readLine()+"\n");
			out.write(s.getBytes());
			 s=new String(br.readLine()+"\n");
			out.write(s.getBytes());
			System.out.println("The Server Replied this:");
			while((by=in.read())!=-1)
			System.out.print((char)by);
			}
		}
		catch(Exception e)
		{
			System.out.println("Oops Exception:"+e);
		}
	}
}