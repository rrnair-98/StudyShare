import java.awt.*;
class BeepDemo
{
	BeepDemo()
	{
		while(true)
		Toolkit.getDefaultToolkit().beep();
	}
	public static void main(String arsg[])
	{
		new BeepDemo();
	}
}