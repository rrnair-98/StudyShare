//import java.util.Scanner;
import java.io.*;
class Swap1 
{
	public static void main(String args[])
	{
       	
         System.out.print("Enter Value of A: ");
         try{
         BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
         //String a= br.readLine();
         String str1=br.readLine();
         System.out.print("Enter Value of B: ");
         String str2=br.readLine();
         int a= Integer.parseInt(str2);
         int b= Integer.parseInt(str1);
     	System.out.println("\nValue of A after Swapping is: "+a);
     	System.out.println("\nValue of B after Swapping is: "+b);
     		}
     	catch(IOException e)
     	{
     		System.out.print("Cant");
     	}

		
		//System.out.println(""+b);
	}
}