import javax.media.*;
import javax.swing.*;
import java.net.*;
import java.awt.*;
import java.io.*;

class VideoExample extends JFrame
{
	Player player; 
	
	VideoExample()
	{
		try 
		{
		player=Manager.createRealizedPlayer(new MediaLocator(new File("Demo.mpg").toURL()));
		add(player.getVisualComponent(),BorderLayout.CENTER);
		add(player.getControlPanelComponent(),BorderLayout.SOUTH);
		player.start();
		setSize(100,100);
		setVisible(true);
		}
		catch(IOException e)
		{
			System.out.println("Opps :"+e);
		}
		catch(NoPlayerException npe)
		{
			System.out.println("NO Player");
		}
		catch(Exception e){System.out.println(e);}
	}
	
	public static void main(String args[])
	{
		new VideoExample();
	}
}