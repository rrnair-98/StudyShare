import java.util.*;
import org.apache.poi.xssf.usermodel.*;

class WriteExcel
{
	XSSFWorkBook workBook;
	WriteExcel()
	{
		Vector row,coloumn,r1,r2;
		row=new Vector();
		coloumn=new Vector();
		coloumn.add(new String("Dhananjay"));
		coloumn.add(new String("Dhananjay"));
		coloumn.add(new String("Dhananjay"));
		coloumn.add(new String("Dhananjay"));
		///////////////////////////////////
		r1=new Vector();
		r1.add(new String("Sanjay"));
		r1.add(new String("Sanjay"));
		r1.add(new String("Sanjay"));
		r1.add(new String("Sanjay"));
		r2=new Vector();
		r2.add(new String("Ghumare"));
		r2.add(new String("Ghumare"));
		r2.add(new String("Ghumare"));
		r2.add(new String("Ghumare"));
		row.add(r1);
		row.add(r2);
		workBook=new XSSFWorkBook();
		XSSFSheet=workBook.createSheet();
		writeUsingVector(row,coloumn,workBook,0,0);
		workBook.write(FileOutputStream fos=new FileOutputStream(WriteExcel.xlsx));
		fos.close();
	}
	
	public static void main(String args[])
	{
		new WriteExcel();
	}
	
	public static writeUsingVector(Vector vectorRow,Vector vectorColoumn,XSSFWorkBook workBookRef,int sheetIndex,int tableIndex)
	{
		int i=0;
		Enumeration e,e1;
		XSSFSheet sheet=workBookRef.getSheetAt(sheetIndex);
		XSSFRow row;
		XSSFCell cell;
		//Table Coloumn
		row=sheet.createRow(tableIndex++);
		e=vectorColoumn.elements();
		while(e.hasMoreElements())
		{
			cell=row.createCell(i++);
			cell.setCellValue((String)e.nextElement());
		}
		//Table Data
		e=vectorRow.elements();
		Vector temp;
		while(e.hasMoreElements())
		{
			temp=(Vector)e.nextElement();
			e1=temp.elements();
			row=sheet.createRow(tableIndex++);
			while(e1.hasMoreElements())
			{
				cell=row.createCell(i++);
				cell.setCellValue((String)e.nextElement());
			}
		}
	}	
}