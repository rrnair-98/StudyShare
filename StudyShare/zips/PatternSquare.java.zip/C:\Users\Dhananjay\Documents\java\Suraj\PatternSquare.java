class PatternSquare
{
	public static void main(String args[])
	{
		int i,j;
		for(i=1;i<=5;i++)
		{
			System.out.println(" ");
			for(j=1;j<=5;j++)
			{
				if(j==1 || j==5)
				{
					System.out.print(i);
				}
				else if(i==1 || i==5)
				{
					System.out.print(j);	
				}
				else
				{
					System.out.print(" ");
				}
			}
		}
	}
}