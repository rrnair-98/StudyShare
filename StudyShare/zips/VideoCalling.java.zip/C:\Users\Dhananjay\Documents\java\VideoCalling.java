import javax.media.*;
 
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.MalformedURLException;

class VideoCalling
{
	Player audioPlayer;
	public VideoCalling(URL url) throws IOException,NoPlayerException,CannotRealizeException 
	{
        audioPlayer = Manager.createPlayer(url);
    }
 
	public VideoCalling(File file) throws IOException,NoPlayerException,CannotRealizeException
	{
        this(file.toURL());
		System.out.println(file.toURL());
		System.out.println("start");
		audioPlayer.start();
    }
	 
	public static void main(String args[])throws Exception 
	{
		File audioFile = new File("C:\\Users\\Dhananjay\\Desktop\\TMA.mp3");
		VideoCalling player = new VideoCalling(audioFile);
	}
}
