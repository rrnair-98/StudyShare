import java.awt.*;
import java.awt.event.*;

class Alphabet extends Frame implements ActionListener
{
	int i,j;
	String str="";
	Button blist[]=new Button[26];
	Alphabet()																														
	{
		super("Hardwell");
		setSize(800,800);
		setLayout(new FlowLayout());
		setFont(new Font("SansSerif",Font.BOLD,30));

		Button b1= new Button("A");
		Button b2= new Button("B");
		Button b3= new Button("C");
		Button b4= new Button("D");
		Button b5= new Button("E");
		Button b6= new Button("F");
		Button b7= new Button("G");
		Button b8= new Button("H");
		Button b9= new Button("I");
		Button b10= new Button("J");
		Button b11= new Button("K");
		Button b12= new Button("L");
		Button b13= new Button("M");
		Button b14= new Button("N");
		Button b15= new Button("O");
		Button b16= new Button("P");
		Button b17= new Button("Q");
		Button b18= new Button("R");
		Button b19= new Button("S");
		Button b20= new Button("T");
		Button b21= new Button("U");
		Button b22= new Button("V");
		Button b23= new Button("W");
		Button b24= new Button("X");
		Button b25= new Button("Y");
		Button b26= new Button("Z");

		blist[0]= (Button) add(b1);
		blist[1]= (Button) add(b2);
		blist[2]= (Button) add(b3);
		blist[3]= (Button) add(b4);
		blist[4]= (Button) add(b5);
		blist[5]= (Button) add(b6);
		blist[6]= (Button) add(b7);
		blist[7]= (Button) add(b8);
		blist[8]= (Button) add(b9);
		blist[9]= (Button) add(b10);
		blist[10]= (Button) add(b11);
		blist[11]= (Button) add(b12);
		blist[12]= (Button) add(b13);
		blist[13]= (Button) add(b14);
		blist[14]= (Button) add(b15);
		blist[15]= (Button) add(b16);
		blist[16]= (Button) add(b17);
		blist[17]= (Button) add(b18);
		blist[18]= (Button) add(b19);
		blist[19]= (Button) add(b20);
		blist[20]= (Button) add(b21);
		blist[21]= (Button) add(b22);
		blist[22]= (Button) add(b23);
		blist[23]= (Button) add(b24);
		blist[24]= (Button) add(b25);
		blist[25]= (Button) add(b26);


		setVisible(true);

		addWindowListener(new Alpha(this));	


		for(int i=0;i<=26;i++)
		{
			blist[i].addActionListener(this);
		}
//_________________________________________________________________________________________________________________________________________________________	
	}

		public void actionPerformed(ActionEvent ae)
		{
			if(ae.getSource()==blist[1])																										//B
			{
				System.out.println("\n\n");
				for(i=0;i<5;i++)
				{
					System.out.println(" ");
					for(j=0;j<5;j++)
						{
							if(j==4 || i==0 || i==2 || i==4)
							{
								System.out.print("*");
							}
							else if(j==0)
							{
								System.out.print("|");
							}
							else
							{
								System.out.print(" ");
							}
						}
					}
				}
//_________________________________________________________________________________________________________________________________________________________			
			else if(ae.getSource()==blist[2])																									//C
			{
				System.out.println("\n\n");
				for(i=0;i<=5;i++)
					{
						System.out.println(" ");
						for(j=0;j<=4;j++)
							{
								if(i==1 || j==0)
							{
								System.out.print("*");
							}
							else if(i==4 || j==5)
								{
									System.out.print("*");
								}
							else
							{
								System.out.print(" ");
							}
						}
					}
		
				}
//_________________________________________________________________________________________________________________________________________________________			
			else if(ae.getSource()==blist[3])																									//D
			{
				System.out.println("\n\n");
					for(i=0;i<5;i++)
						{
							System.out.println(" ");
							for(j=0;j<5;j++)
								{
									if(j==4 || i==0 || i==4)
									{
										System.out.print("*");
									}
									else if(j==0)
									{
										System.out.print("|");
									}
									else
									{
										System.out.print(" ");
									}
								}
						}
			}	
//_________________________________________________________________________________________________________________________________________________________
			else if(ae.getSource()==blist[3])																									//E
			{
				System.out.println("\n\n");
					for(i=0;i<=4;i++)
						{
							System.out.println(" ");
							for(j=0;j<=4;j++)
							{
								if(i==0 || j==0)
								{
									System.out.print("*");
								}
								else if(i==2 || i==4)
								{
									System.out.print("*");
								}
								else
								{
									System.out.print(" ");
								}
							}
						}
			}			
//_________________________________________________________________________________________________________________________________________________________
			else if(ae.getSource()==blist[4])																									//F
			{
				System.out.println("\n\n");
						for(i=0;i<=4;i++)
						{
							System.out.println(" ");
							for(j=0;j<=4;j++)
							{
								if(i==0 || j==0)
								{
									System.out.print("*");
								}
								else if(i==2 || i==4)
								{
									System.out.print("*");
								}
								else
								{
									System.out.print(" ");
								}
							}
						}
		
			}
//_________________________________________________________________________________________________________________________________________________________
			else if(ae.getSource()==blist[5])																									//G
			{
				System.out.println("\n\n");
				for(i=0;i<=4;i++)
				{
			System.out.println(" ");
			for(j=0;j<=4;j++)
			{
				if(i==0 || i==2)
				{
					System.out.print("*");
				}
				else if(j==0)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
		}
			}
//_________________________________________________________________________________________________________________________________________________________			
			else if(ae.getSource()==blist[6])																									//H
			{
				System.out.println("\n\n");
				for(i=0;i<5;i++)
				{
			System.out.println(" ");
			for(j=0;j<5;j++)
			{
				if(i==2 || i==0 || j==4 || i==4)
				{
					System.out.print("*");
				}
				else if(j==i+1)
				{
					System.out.print("*  ");
				}
				else
				{
					System.out.print(" ");
				}
			}
		}
			}
//_________________________________________________________________________________________________________________________________________________________			
			else if(ae.getSource()==blist[7])																									
			{
				System.out.println("\n\n");
				for(i=0;i<=4;i++)
			{
			System.out.println(" ");
			for(j=0;j<=4;j++)
			{
				if(j==0 || j==4)
				{
					System.out.print("*");
				}
				else if(i==2)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
		}
			}
//_________________________________________________________________________________________________________________________________________________________
		else if(ae.getSource()==blist[8])																										
		{
			System.out.println("\n\n");
			for(i=0;i<=4;i++)
		{
			System.out.println(" ");
			for(j=0;j<=4;j++)
			{
				if(i==0 || i==4)
				{
					System.out.print("*");
				}
				else if(j==2)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
		}
		}
//_________________________________________________________________________________________________________________________________________________________		
		else if(ae.getSource()==blist[9])
		{
			System.out.println("\n\n");
			for(i=0;i<5;i++)
		{
			System.out.println(" ");
			for(j=0;j<5;j++)
			{
				if(j==2 || i==0)
				{
					System.out.print("*");
				}
				else if(i==j+4)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
		}
		}
//_________________________________________________________________________________________________________________________________________________________		
		else if(ae.getSource()==blist[11])
		{
			System.out.println("\n\n");
			for(i=0;i<=4;i++)
		{
			System.out.println(" ");
			for(j=0;j<=4;j++)
			{
				if(i==4 || j==0)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
		}

		}
//_________________________________________________________________________________________________________________________________________________________		
		else if(ae.getSource()==blist[13])
		{
			System.out.println("\n\n");
			for(i=0;i<=4;i++)
		{
			System.out.println(" ");
			for(j=0;j<=4;j++)
			{
				if(j==0 || j==4)
				{
					System.out.print("*");
				}
				else if(i==j)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
		}

		}	
//_________________________________________________________________________________________________________________________________________________________		
		else if(ae.getSource()==blist[14])
		{
			System.out.println("\n\n");
			for(i=0;i<=4;i++)
		{
			System.out.println(" ");
			for(j=0;j<=4;j++)
			{
				if(j==0 || j==4)
				{
					System.out.print("*");
				}
				else if(i==0 || i==4)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
		}	}
		}
//_________________________________________________________________________________________________________________________________________________________		
		else if(ae.getSource()==blist[15])
		{
			System.out.println("\n\n");
			for(i=0;i<5;i++)
		{
			System.out.println(" ");
			for(j=0;j<5;j++)
			{
				if(i==2 || i==0  || j==0)
				{
					System.out.print("*");
				}
				else if(i+j==3)
				{
					System.out.print("  *");
				}
				else
				{
					System.out.print(" ");
				}
			}
		}
		}
//_________________________________________________________________________________________________________________________________________________________
		else if(ae.getSource()==blist[16])
		{
			System.out.println("\n\n");
			for(i=0;i<5;i++)
		{
			System.out.println(" ");
			for(j=0;j<5;j++)
			{
				if(i==0 || i==4)
				{
					System.out.print("*");
				}
				else if(j==0 || j==4)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
		}
		for(i=4;i<8;i++)
		{
			System.out.println(" ");
			for(j=0;j<7;j++)
			{
				if(i==j)
				{System.out.print("*");}
				else{System.out.print(" ");}
				
			}
		}
		}
//_________________________________________________________________________________________________________________________________________________________
		else if(ae.getSource()==blist[17])
		{
			System.out.println("\n\n");
			for(i=0;i<5;i++)
		{
			System.out.println(" ");
			for(j=0;j<5;j++)
			{
				if(i==0 || i==4)
				{
					System.out.print("*");
				}
				else if(j==0 || j==4)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
		}
		for(i=0;i<5;i++)
		{
			System.out.println(" ");
			for(j=0;j<5;j++)
			{
				if(i==j || j==0)
				{System.out.print("*");}
				else{System.out.print(" ");}
				
			}
		}
		}	
//_________________________________________________________________________________________________________________________________________________________
		else if(ae.getSource()==blist[18])
		{
			System.out.println("\n\n");
			for(i=0;i<5;i++)
		{
			System.out.println(" ");
			for(j=0;j<5;j++)
			{
				if(i==0 || i==4)
				{
					System.out.print("*");
				}
				else if(i==j)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
		}
		}	
//_________________________________________________________________________________________________________________________________________________________		
		else if(ae.getSource()==blist[19])
		{
			System.out.println("\n\n");
			for(i=0;i<=4;i++)
		{
			System.out.println(" ");
			for(j=0;j<=4;j++)
			{
				if(i==0 || j==2)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
		}
		}
//_________________________________________________________________________________________________________________________________________________________		
		else if(ae.getSource()==blist[20])
		{
			System.out.println("\n\n");
			for(i=0;i<=4;i++)
		{
			System.out.println(" ");
			for(j=0;j<=4;j++)
			{
				if(j==0 || j==4)
				{
					System.out.print("*");
				}
				else if(i==4)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
		}
		}	
//_________________________________________________________________________________________________________________________________________________________		
		else if(ae.getSource()==blist[21])
		{
			System.out.println("\n\n");
			for(i=0;i<4;i++)
		{
			System.out.println(" ");
			for(j=0;j<=6;j++)
			{
				if(i==j)
				{
					System.out.print("*");
				}
				else if(i+j==6)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
				
			}
		}
		}
//_________________________________________________________________________________________________________________________________________________________		
		else if(ae.getSource()==blist[23])
		{
			System.out.println("\n\n");
			for(i=0;i<=5;i++)
		{
			System.out.println(" ");
			for(j=0;j<=5;j++)
			{
				if(i==j || i+j==5)
				{
					System.out.print("*");
				}
				/*else if(i=0 && j=5)
				{
					System.out.print("*");
					i++;
					j--;
				}*/
				else
				{
					System.out.print(" ");
				}
			}
		}	
		}
//_________________________________________________________________________________________________________________________________________________________	
		else if(ae.getSource()==blist[24])
		{
			System.out.println("\n\n");
			for(i=0;i<4;i++)
		{
			System.out.println(" ");
			for(j=0;j<=6;j++)
			{
				if(i==j)
				{
					System.out.print("*");
				}
				else if(i+j==6)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
				
			}
		}
		for(i=4;i<=6;i++)
		{
			System.out.println(" ");
			for(j=0;j<=9;j++)
			{
				if(i+j==6)
				{
					System.out.print("*");
				}
				else{System.out.print(" ");}
			}
		}
		}
//_________________________________________________________________________________________________________________________________________________________		
		else if(ae.getSource()==blist[25])
		{
			System.out.println("\n\n");
			for(i=0;i<5;i++)
		{
			System.out.println(" ");
			for(j=0;j<5;j++)
			{
				if(i==0 || i==4)
				{
					System.out.print("*");
				}
				else if(i+j==4)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
		}
		}
		//String str= blist[0].getActionCommand();
		repaint();			

	}
		public void paint(Graphics g)
		{
			String str= ae.getActionCommand();
			String msg="";
			if(str.equals("A"))
			{
				msg="For Apple";
			}
			g.drawString(msg,500,500);
		}

//_________________________________________________________________________________________________________________________________________________________

		public static void main(String args[])
		{
			Alphabet a1= new Alphabet();
		}


}
//_________________________________________________________________________________________________________________________________________________________
 class Alpha extends WindowAdapter
 {
 	Alphabet f;
 	Alpha(Alphabet ref)
 	{
 		f=ref;
 	}
 	public void windowClosing(WindowEvent we)
 	{
 		f.dispose();
 	}
 }
 //_________________________________________________________________________________________________________________________________________________________
 //_________________________________________________________________________________________________________________________________________________________
 //_________________________________________________________________________________________________________________________________________________________
 //_________________________________________________________________________________________________________________________________________________________