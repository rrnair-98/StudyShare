import javax.swing.*;
import java.awt.*;

class FrameCheck
{
	Frame f;
	Panel p,p1;
	Button add;
	FrameCheck()
	{
		p1=new Panel();
		p=new Panel();
		f=new Frame();
		f.add(p);
		f.add(p1);
		check(p);
		check(p1);
		while(true)
		{
			try
			{
				Thread.sleep(1000);
			}
			catch (Exception e)
			{
			}
			Toolkit.getDefaultToolkit().beep();
		}
	}

	public static void main(String args[])
	{
		new FrameCheck();
	}

	public void check(Component parent)
	{
		Frame owner=null;
		owner=(Frame)SwingUtilities.getAncestorOfClass(Frame.class,parent);
		if(owner==f)
			System.out.println("Success");
	}
	
}
