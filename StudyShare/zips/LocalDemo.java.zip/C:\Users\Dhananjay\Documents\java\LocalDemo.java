import java.net.*;

class LocalDemo
{
	InetAddress obj;
	LocalDemo()
	{
		try
		{
			System.out.println(obj=InetAddress.getLocalHost());
			//System.out.println(obj=InetAddress.getByName("www.facebook.com"));
			System.out.println(obj.isMulticastAddress());
			System.out.println(obj.getLoopbackAddress());
			//System.out.println(obj.getAllByName("www.google.com"));
			System.out.println(obj.getAddress());
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}
	public static void main(String args[] )
	{
		new LocalDemo();
	}
}