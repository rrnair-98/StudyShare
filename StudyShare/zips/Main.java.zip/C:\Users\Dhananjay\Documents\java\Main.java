import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
class Main extends JFrame implements ActionListener
{
	int i=0;
	JButton jb;
	CScroll obj;
	Main()
	{
		setLayout(null);
		obj=new CScroll();
		add(obj,BorderLayout.SOUTH);
		obj.setBounds(0,450,500,55);
		add(jb=new JButton("hello"),BorderLayout.CENTER);
		jb.addActionListener(this);
		jb.setBounds(0,0,100,100);
		setSize(500,550);
		setVisible(true);
	}
	
	public static void main(String args[])
	{
		new Main();
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		System.out.println("Dhaanjay");
		obj.jp.add(new MyButton("C"+i++));
		setSize(500,549);
		setSize(500,550);
	}
}

class CScroll extends JScrollPane
{
	JPanel jp;
	CScroll()
	{
		jp=new JPanel();
		jp.setLayout(new FlowLayout(FlowLayout.LEFT));
		//setLayout(new BorderLayout());
		getViewport().add(jp);
	}
}

class MyButton extends JButton
{
	JPopupMenu jpm;
	JMenuItem avail,navail,comp;
	MyButton(String str)
	{
		super(str);
		jpm=new JPopupMenu("STATUS");
		jpm.add(comp=new JMenuItem("Completed"));
		comp.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae)
			{
			setBackground(new Color(0,0,255));
			}
		});
		jpm.add(avail=new JMenuItem("avail"));
		avail.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae)
			{
			setBackground(new Color(0,255,0));
			}
		});
		jpm.add(navail=new JMenuItem("not avail"));
		navail.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
			setBackground(new Color(255,0,0));
			}
		});
		
		addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				System.out.println("Hello");
				jpm.show(MyButton.this,0,0);
			}
		});
	}
}

