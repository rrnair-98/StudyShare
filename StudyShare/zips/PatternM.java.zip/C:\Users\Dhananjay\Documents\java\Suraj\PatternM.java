class PatternM
{
	public static void main(String[] args) 
	{
		int i,j;
		for(i=0;i<4;i++)
		{
			System.out.println(" ");
			for(j=0;j<=6;j++)
			{
				if(i==j || j==0 || j==6)
				{
					System.out.print("*");
				}
				else if(i+j==6)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
				
			}
		}
	}
}
