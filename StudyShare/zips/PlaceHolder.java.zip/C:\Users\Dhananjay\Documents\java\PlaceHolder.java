import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

class PlaceHolder extends JFrame implements FocusListener 
{
	JTextField j,j1;
	PlaceHolder()
	{
		j1=new JTextField(10);
		j=new JTextField(15);
		j.setForeground(new Color(100,100,100));
		j.setText("Enter the Password");
		setLayout(new FlowLayout());
		j.addFocusListener(this);
		add(j1);
		add(j);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(500,500);
		setVisible(true);
	}
	public static void main(String[] args) 
	{
		new PlaceHolder();
		
	}
	
	public void focusLost(FocusEvent fe)
	{
		if(j.getText().length()==0)
		{
			j.setText("Enter the Password");
			j.setForeground(new Color(100,100,100));
		}
	}

	public void focusGained(FocusEvent fe)
	{
		if(j.getText().equals("Enter the Password"))
		{
			j.setForeground(new Color(0,0,0));
			j.setText("");
		}
	}

}
