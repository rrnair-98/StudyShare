class Obj
{
	public static void main(String args[]){
		while(true);
	}
}