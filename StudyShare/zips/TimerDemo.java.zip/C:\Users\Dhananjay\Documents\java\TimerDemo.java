import javax.swing.*;
import java.awt.event.*;
class TimerDemo
{

	TimerDemo()
	{
	}
	public static void main(String args[])
	{
			Timer t;
	ActionListener action=new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				System.out.println("Action Performed");
			}
		};
		new Timer(1000,action).start();
		//t.setRepeats(false);
		System.out.println("After Starting");
	}
}