import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class PopupDemo extends JFrame 
{
	int i=100,j=100;
	Popup p1;
	JButton show,hide;
	PopupDemo()
	{
		p1=PopupFactory.getSharedInstance().getPopup(this,new MyPanel(),100,100);
		show=new JButton("POPUP");
		hide=new JButton("Close");
		show.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				p1=PopupFactory.getSharedInstance().getPopup(PopupDemo.this,new MyPanel(),i++,i++);
				p1.show();
			}
		});
		hide.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				p1.hide();
			}
		});
		add(show,BorderLayout.NORTH);
		add(hide,BorderLayout.SOUTH);
		setSize(500,500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}

	

	public static void main(String args[])
	{
		new PopupDemo();
	}
}

class MyPanel extends JPanel
{
	MyPanel()
	{
		add(new JButton("HELLO"));
		add(new JButton("HELLO"));
		setSize(200,200);
		setBackground(new Color(100,100,100));
	}
}