import javax.swing.*;
import java.awt.event.*;
import javax.accessibility.*;
class AccessibleDemo extends JFrame
{
	JButton jb;
	AccessibleDemo()
	{
		jb=new JButton("Hello");
		jb.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				System.out.println("Clicked");
			}
		});
		add(jb);
		setVisible(true);
		setSize(100,100);

		try
		{
			Thread.sleep(1000);
		}
		catch (Exception e)
		{
		}
		jb.getAccessibleContext().getAccessibleAction().doAccessibleAction(0);
	}
	public static void main(String args[])
	{
		new AccessibleDemo();
		
	}
}