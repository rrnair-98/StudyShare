import java.awt.*;
import java.awt.event.*;

class ListDemo extends Frame implements ItemListener 
{
	String msg="";
	List l1;
	ListDemo()
	{
	super("Hardwell");
	setLayout(new FlowLayout());
	setSize(400,400);
	l1= new List(4,true);
	l1.add("Suraj");
	l1.add("Dhananjay");
	l1.add("Kaustubh");
	l1.add("Jainam");
	l1.addItemListener(this);
	add(l1);
	setVisible(true);
	}
	public void itemStateChanged(ItemEvent ie)
	{
		String str=l1.getSelectedItem();
		if(str.equals("Suraj"))
		{
			msg="Current item";
		}
			else if(str.equals("Dhananjay"))
				{
					msg="Current item";
				}
			else if(str.equals("Kaustubh"))
				{
					msg="Current item";
				}
			else {msg="Current item";}
		}
		public void paint(Graphics g)
		{
			g.drawString(msg,6,100);
		}
	
	public static void main(String args[])
	{
		ListDemo f1= new ListDemo();
	}
}
