import java.io.*;
class  FileDemo
{
	FileDemo()
	{
		try
		{
			if(new File("Dhananjay.txt").createNewFile())
			System.out.println("Dhananjay");
		}
		catch (Exception e)
		{
		}
		
	}
	public static void main(String[] args) 
	{
		new FileDemo();
	}
}
