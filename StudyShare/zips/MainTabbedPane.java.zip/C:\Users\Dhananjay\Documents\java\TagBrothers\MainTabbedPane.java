package TagBrothers;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import TagBrothers.*;
public class MainTabbedPane extends JTabbedPane 
{
	AddPanel add_Tab;
	MessageAllPanel message_All_Tab;
	CustomerScrollPane customerQueue;
	public MainTabbedPane(int pos,CustomerScrollPane ref)
	{
		super(pos);
		customerQueue=ref;
		initializeAll();
		addAll();
	}
	
	void initializeAll()
	{
		add_Tab=new AddPanel(customerQueue);
		message_All_Tab=new MessageAllPanel();
	}
	
	void addAll()
	{
		add("ADD",add_Tab);
		add("MESSAGE ALL",message_All_Tab);
		//add("TALLY",add_Tab=new AddPanel());
	}
}