class Demo{
    public static void main(String args[])
    {
        new Demo();
        System.out.println("Hello World");
    }
}