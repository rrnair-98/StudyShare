import javax.swing.*;
 
 class DialogDemo extends JFrame
 {
	 JDialog j;
	 DialogDemo()
	 {
		j=new JDialog(this);
		j.setSize(500,500);
		j.setVisible(true);
	 }

	 public static void main(String args[])
	 {
		 new DialogDemo();
	 }

 }