import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;

class FindReplaceDemo extends JFrame 
{
	FindReplaceDialog dialog = null;
	JTextArea ta;
	JButton findButton ,replaceButton;
	FindReplaceDemo()
	{
		super("Find Replace Demo");
		ta=new JTextArea(7,20);
		findButton=new JButton("Find Text");
		ActionListener ac1 =new ActionListener()
	    {
			public void actionPerformed(ActionEvent ae)
			{
				if(dialog==null)
					dialog=new FindReplaceDialog(FindReplaceDemo.this.ta);
				dialog.showFindReplaceDialog(FindReplaceDemo.this,true);
			}
		};
		findButton.addActionListener(ac1);

		replaceButton=new JButton("Replace Text");
		ActionListener ac2 =new ActionListener()
	    {
			public void actionPerformed(ActionEvent ae)
			{
				if(dialog==null)
					dialog=new FindReplaceDialog(FindReplaceDemo.this.ta);
				dialog.showFindReplaceDialog(FindReplaceDemo.this,false);
			}
		};
		replaceButton.addActionListener(ac2);

		add(ta,BorderLayout.CENTER);
		add(findButton,BorderLayout.NORTH);
		add(replaceButton,BorderLayout.SOUTH);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setBounds(50,50,400,400);
	}

	public static void main(String args[])
	{
		new FindReplaceDemo();
	}
}

interface FindReplaceConstants
{
	String REPLACELABEL = "Replace With:";
	String FINDLABEL = "Find What:";
	String MATCHCASE = "Match Case";
	String UP = "Up";
	String DOWN = "Down";
	String BTN_FIND_NEXT = "Find Next";
	String BTN_REPLACE = "Replace";
	String BTN_REPLACE_ALL = "Replace All";
	String BTN_CANCEL = "Cancel";
	String BORDER_TITLE = "Direction";
}

public class FindReplaceDialog extends JPanel implements FindReplaceConstants, ActionListener
{
	JTextArea taSource;
	int startIndex;
	JLabel lblReplace,lblFind;
	JTextField txtFind,txtReplace;
	JCheckBox cbMatchCase;
	JRadioButton rbUp,rbDown;
	JButton btnFindNext,btnReplace,btnReplaceAll,btnCancel;
	JDialog dialog;
	JPanel directionPanel,southPanel,buttonPanel,textPanel;

	public FindReplaceDialog(JTextArea ref)
	{
		taSource = ref;
		initializeAll();
		createAndMakePanels();
		setLayout( new BorderLayout());
		add(textPanel,BorderLayout.CENTER);
		add(southPanel,BorderLayout.SOUTH);
		add(buttonPanel,BorderLayout.EAST);
		handelButtons();
	}

	void createAndMakePanels()
	{
		ButtonGroup bg =new ButtonGroup();
		bg.add(rbUp);
		bg.add(rbDown);
		rbDown.setSelected(true);
		
		Border etchedBorder = BorderFactory.createEtchedBorder();
		Border titledBorder = BorderFactory.createTitledBorder(etchedBorder,BORDER_TITLE);

		directionPanel.setBorder(titledBorder);
		directionPanel.setLayout(new GridLayout(1,2));
		directionPanel.add(rbUp);
		directionPanel.add(rbDown);

		southPanel.setLayout(new GridLayout(1,2));
		southPanel.add(cbMatchCase);
		southPanel.add(directionPanel);

		buttonPanel.setLayout(new GridLayout(4,1));
		buttonPanel.add(btnFindNext);
		buttonPanel.add(btnReplace);
		buttonPanel.add(btnReplaceAll);
		buttonPanel.add(btnCancel);

		textPanel.setLayout(new GridLayout(3,2));
		textPanel.add(lblFind);
		textPanel.add(txtFind);
		textPanel.add(lblReplace);
		textPanel.add(txtReplace);
		textPanel.add(new JLabel(""));
		textPanel.add(new JLabel(""));

	}

	void initializeAll()
	{
		lblReplace = new JLabel(REPLACELABEL);
		lblFind = new JLabel(FINDLABEL);

		txtFind = new JTextField(20);
		txtReplace = new JTextField(20);

		cbMatchCase = new JCheckBox(MATCHCASE);
		rbUp=new JRadioButton(UP);
		rbDown=new JRadioButton(DOWN);

		btnFindNext =new JButton(BTN_FIND_NEXT);
		btnReplace =new JButton(BTN_REPLACE);
		btnReplaceAll =new JButton(BTN_REPLACE_ALL);
		btnCancel = new JButton(BTN_CANCEL);

		directionPanel = new JPanel();
		southPanel  = new JPanel();
		buttonPanel  = new JPanel();
		textPanel  = new JPanel();

		btnFindNext.addActionListener(this);
		btnReplace.addActionListener(this);
		btnReplaceAll.addActionListener(this);
		btnCancel.addActionListener(this);

		txtFind.getDocument().addDocumentListener(new DocumentListener()
		{
			public void changedUpdate(DocumentEvent de)
			{handelButtons();}
			public void insertUpdate(DocumentEvent de)
			{handelButtons();}
			public void removeUpdate(DocumentEvent de)
			{handelButtons();}
		});
	}

	void handelButtons()
	{
		if(txtFind.getText().length()==0)
		{
			//disable
			btnFindNext.setEnabled(false);
			btnReplace.setEnabled(false);
			btnReplaceAll.setEnabled(false);
		}
		else
		{
			btnFindNext.setEnabled(true);
			btnReplace.setEnabled(true);
			btnReplaceAll.setEnabled(true);
		}
	}

	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==btnFindNext)
			find();
		else if(ae.getSource()==btnReplace)
			replace();
		else if(ae.getSource()==btnReplaceAll)
			replaceAll();
		else if(ae.getSource()==btnCancel)
			dialog.dispose();
	}

	int search()
	{
		int selStart,selEnd;

		String src=taSource.getText();
		String key=txtFind.getText();

		startIndex=taSource.getCaretPosition();

		selStart=taSource.getSelectionStart();
		selEnd=taSource.getSelectionEnd();

		if(rbUp.isSelected())
		{
			if(selStart!=selEnd)
			{
				startIndex=selStart-1;
			}
			
			if(cbMatchCase.isSelected())
				startIndex=src.lastIndexOf(key,startIndex);
			else 
				startIndex=src.toUpperCase().lastIndexOf(key.toUpperCase(),startIndex);
		}
		else
		{
			if(selStart!=selEnd)
			{
				startIndex=selStart+1;
			}
			
			if(cbMatchCase.isSelected())
				startIndex=src.indexOf(key,startIndex);
			else 
				startIndex=src.toUpperCase().indexOf(key.toUpperCase(),startIndex);
		}
		return startIndex;
	}

	void find()
	{
		int idx= search();
		if(idx!=-1)
		{
			taSource.requestFocus();
			taSource.select(idx,idx + txtFind.getText().length());
		}
		else
			JOptionPane.showMessageDialog(this,"Cannot find \""+txtFind.getText()+"\"","Notepad",JOptionPane.INFORMATION_MESSAGE);
	}

	void replace()
	{
		String selectedText =taSource.getSelectedText();
		if(selectedText == null || selectedText.length()==0)
		{
			find();
			return;
		}

		String key=txtFind.getText();
		String repText =txtReplace.getText();
		if((cbMatchCase.isSelected() && selectedText.equals(key)) || (!cbMatchCase.isSelected() && selectedText.equalsIgnoreCase(key)))
		{
			//replace the text
			taSource.replaceSelection(repText);
		}
		find();
	}

	void replaceAll()
	{
		String repText=txtReplace.getText();
		if(rbUp.isSelected())
			taSource.setCaretPosition(taSource.getText().length()-1);
		else 
			taSource.setCaretPosition(0);
		
		int idx=-1;
		int count=0;
		while(true)
		{
			idx=search();
			if(idx==-1)
				break;
			count++;
			taSource.replaceRange(repText,idx,idx+txtFind.getText().length());
		}
		JOptionPane.showMessageDialog(this,"Total Replacement made = "+count);
	}

	public void showFindReplaceDialog(Component parent,boolean isFind)
	{
		Frame owner=null;
		if(parent instanceof Frame)
			owner=(Frame)parent;
		else
			owner=(Frame)SwingUtilities.getAncestorOfClass(Frame.class,parent);

		if(dialog == null)
		{
			dialog=new JDialog(owner,false);
			dialog.add(this);
			dialog.setResizable(false);
			dialog.getRootPane().setDefaultButton(btnFindNext);
		}
		if(txtFind.getText().length()==0)
			btnFindNext.setEnabled(false);
		else
			btnFindNext.setEnabled(true);

		btnReplace.setVisible(false);
		btnReplaceAll.setVisible(false);
		lblReplace.setVisible(false);
		txtReplace.setVisible(false);

		if(isFind)
			dialog.setTitle("Find");
		else
		{
			dialog.setTitle("Replace");
			btnReplace.setVisible(true);
			btnReplaceAll.setVisible(true);
			lblReplace.setVisible(true);
			txtReplace.setVisible(true);
		}
		dialog.setVisible(true);
		dialog.setSize(400,180);
	}
}

