package packageDemo;
import packageDemo.p1.*;

public class A
{
	public A()
	{
		B obj=new B();
		obj.show();
	}

	public static void main(String args[])
	{
		new A();
	}

	public void callPratik()
	{
		System.out.println("Pratik loves VESp");
	}
}