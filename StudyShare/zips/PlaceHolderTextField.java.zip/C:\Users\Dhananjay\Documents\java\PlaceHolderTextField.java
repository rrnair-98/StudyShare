import javax.swing.text.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class PlaceHolderTextField extends JTextField 
{
	DefaultCaret dc=new DefaultCaret();
	PlaceHolderTextField(int count,String placeHolder)
	{
		super(10);
		
		setText(placeHolder);
		setCaretPosition(0);
		setForeground(Color.LIGHT_GRAY);
		
		
		
		
		
		addKeyListener(new KeyAdapter()
		{
			public void keyTyped(KeyEvent ke)
			{
				if (ke.getKeyCode()==ke.VK_RIGHT)
				{
					ke.consume();
					System.out.println("Hello we consumed it");
				}
				System.out.println("Typed");
				if((ke.getKeyChar()==(char)8)&&getText().equals(placeHolder))
				{
						System.out.println("Inside VK");
					ke.consume();
					System.out.println("Consumed");
				}
				else 
				{
					System.out.println("Inside V");
					if(getText().equals(placeHolder))
						setText("");
					else if(getText().equals(""))
						setText(placeHolder);
				}
			}
		});
		
		addCaretListener(new CaretListener()
		{
			public void caretUpdate(CaretEvent ce)
			{
				if(getText().equals(placeHolder))
					setCaretPosition(0);
			}
		});
		
		getDocument().addDocumentListener(new DocumentListener()
		{
			public void insertUpdate(DocumentEvent fe)
			{
				System.out.println("Inserted");
			}
			
			public void removeUpdate(DocumentEvent de)
			{
				System.out.println("Removed");
			}
			
			public void changedUpdate(DocumentEvent de)
			{
				System.out.println("Changed");
			}
		});
	}
}

class PlaceHolderDemo extends JFrame
{
	PlaceHolderTextField textField;
	JTextField jtf;
	PlaceHolderDemo()
	{
		jtf=new JTextField("hello");
		textField=new PlaceHolderTextField(20,"Hello");
		setLayout(new FlowLayout());
		add(jtf);
		add(textField);
		setSize(100,100);
		setVisible(true);
	}
	
	public static void main(String args[])
	{
		new PlaceHolderDemo();
	}
}