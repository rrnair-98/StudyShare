import java.net.*;
import java.io.*;
class MyServer
{
	public static void main(String args[])
	{
		try(ServerSocket server=new ServerSocket(4444))
		{
			Socket client=server.accept();
			
			InputStream in=client.getInputStream();
			OutputStream out=client.getOutputStream();
			while(true)
			{
				int by;
				int i=0;
			byte arr[]=new byte[100];
			while(( by=in.read())!=-1)
			{
				System.out.println((char)by);
			arr[i++]=(byte)by;
			break;
			}
			System.out.println("Done");
			System.out.println(new String(arr));
			out.write(arr);
			}
		}
		catch(Exception e)
		{
			System.out.println("Oops Exception:"+e);
		}
	}
}