import java.awt.*;
import javax.swing.*;
class TabbedPaneDemo extends JFrame 
{
	JTabbedPane jp;
	TabbedPaneDemo()
	{
		jp=new JTabbedPane();
		jp.add("Button",new JButton("JIANAM"));
		jp.add("Button",new JButton("PRATIK"));
		add(jp);
		setSize(100,100);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	public static void main(String[] args) 
	{
		new TappedPaneDemo();
	}
}
