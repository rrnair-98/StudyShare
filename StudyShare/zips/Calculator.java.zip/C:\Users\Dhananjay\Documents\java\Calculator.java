import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;

class Calculator extends JFrame implements ActionListener
{
	JButton num_Btn[],add_Btn,sub_Btn,mul_Btn,div_Btn,ans_Btn,cancel_Btn,clear_Btn,back_Btn,dot_Btn,sign_Btn;
	JTextField big_Txt,small_Txt;
	JPanel txt_Panel,num_Panel;
	int num1=0,num2=0,current_Operation=0;
	boolean replace_Txt=true,is_Operator_Sum=false,is_Blocked=false,is_Small_Txt=false,is_Negate=false,is_Cannot_Divide_By_Zero=false;
	String equation;
	
	Calculator()
	{
		init();
		addAll();
		addListeners();
		setSize(500,500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	void init()
	{
		num_Btn=new JButton[10];
		for(int i=0;i<10;i++)
		{
			num_Btn[i]=new JButton(new Integer(i).toString());
		}
		dot_Btn=new JButton(".");
		sign_Btn=new JButton("+-");
		clear_Btn=new JButton("CE");
		cancel_Btn=new JButton("C");
		back_Btn=new JButton("<-");
		add_Btn=new JButton("+");
		sub_Btn=new JButton("-");
		mul_Btn=new JButton("*");
		div_Btn=new JButton("/");
		ans_Btn=new JButton("=");
		big_Txt=new JTextField(10);
		small_Txt=new JTextField(10);
		txt_Panel=new JPanel();
		num_Panel=new JPanel();
		equation="";
	}
	
	void addAll()
	{
		big_Txt.setText("0");
		
		txt_Panel.setLayout(new GridLayout(2,1));
		txt_Panel.add(small_Txt);
		txt_Panel.add(big_Txt);
		add(txt_Panel,BorderLayout.NORTH);
		
		num_Panel.setLayout(new GridLayout(5,4));
		for(int i=0;i<10;i++)
		{
			num_Panel.add(num_Btn[i]);
		}
		num_Panel.add(add_Btn);
		num_Panel.add(sub_Btn);
		num_Panel.add(mul_Btn);
		num_Panel.add(div_Btn);
		num_Panel.add(dot_Btn);
		num_Panel.add(sign_Btn);
		num_Panel.add(cancel_Btn);
		num_Panel.add(clear_Btn);
		num_Panel.add(back_Btn);
		num_Panel.add(ans_Btn);
		add(num_Panel,BorderLayout.CENTER);
	}
	
	void addListeners()
	{
		for(int i=0;i<10;i++)
		{
			num_Btn[i].addActionListener(this);
		}
		
		add_Btn.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				if(!is_Negate)
				{
					if(is_Blocked)
						small_Txt.setText(equation=equation.substring(0,equation.length()-1)+"+");
					else
						small_Txt.setText(equation=equation+big_Txt.getText()+"+");
				}
				else
					small_Txt.setText(equation+"+");
				
				if(is_Operator_Sum)
				{
					num2=Integer.parseInt(big_Txt.getText());
					if(!is_Blocked)
						performOperation();
				}
				try{
				num1=Integer.parseInt(big_Txt.getText());
				replace_Txt=true;
				is_Operator_Sum=true;
				is_Blocked=true;
				is_Negate=false;
				current_Operation=1;
				}catch(Exception e){}
				System.out.println("Pressed");
			}
		});
		
		sub_Btn.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				if(!is_Negate)
				{
					if(is_Blocked)
						small_Txt.setText(equation=equation.substring(0,equation.length()-1)+"-");
					else
						small_Txt.setText(equation=equation+big_Txt.getText()+"-");
				}
				else
					small_Txt.setText(equation+"-");
				
				if(is_Operator_Sum)
				{
					num2=Integer.parseInt(big_Txt.getText());
					if(!is_Blocked)
						performOperation();
				}
				try{
				num1=Integer.parseInt(big_Txt.getText());
				replace_Txt=true;
				is_Operator_Sum=true;
				is_Blocked=true;
				is_Negate=false;
				current_Operation=2;
				}catch(Exception e)
				{
					System.out.println("Dhananjay");
				}
				System.out.println("Pressed");
			}
		});
		
		mul_Btn.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				if(!is_Negate)
				{
					if(is_Blocked)
						small_Txt.setText(equation=equation.substring(0,equation.length()-1)+"*");
					else
						small_Txt.setText(equation=equation+big_Txt.getText()+"*");
				}
				else
					small_Txt.setText(equation+"*");
				
				if(is_Operator_Sum)
				{
					num2=Integer.parseInt(big_Txt.getText());
					if(!is_Blocked)
						performOperation();
				}
				try{
				num1=Integer.parseInt(big_Txt.getText());
				replace_Txt=true;
				is_Operator_Sum=true;
				is_Blocked=true;
				is_Negate=false;
				current_Operation=3;
				}catch(Exception e){}
				System.out.println("Pressed");
			}
		});
		
		div_Btn.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				if(!is_Negate)
				{
					if(is_Blocked)
						small_Txt.setText(equation=equation.substring(0,equation.length()-1)+"/");
					else
					small_Txt.setText(equation=equation+big_Txt.getText()+"/");
				}
				else
					small_Txt.setText(equation+"/");
				if(is_Operator_Sum)
				{
					num2=Integer.parseInt(big_Txt.getText());
					if(!is_Blocked)
						performOperation();
				}
				try{
				num1=Integer.parseInt(big_Txt.getText());
				replace_Txt=true;
				is_Operator_Sum=true;
				is_Blocked=true;
				is_Negate=false;
				current_Operation=4;
				}catch(Exception e){}
				System.out.println("Pressed");
			}
		});
		
		ans_Btn.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				num2=Integer.parseInt(big_Txt.getText());
				performOperation();
				is_Operator_Sum=false;
				replace_Txt=true;
				is_Negate=false;
				equation="";
				small_Txt.setText(equation);
				System.out.println("Pressed");
			}
		});
		
		clear_Btn.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				if((!is_Operator_Sum)&&current_Operation==0)
					small_Txt.setText(equation="");
				big_Txt.setText("0");
				replace_Txt=true;
			}
		});
		
		back_Btn.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				if(!is_Blocked)
				{
					if(big_Txt.getText().length()>1)
						big_Txt.setText(big_Txt.getText().substring(0,big_Txt.getText().length()-1));
					else
					{
						big_Txt.setText("0");
						replace_Txt=true;
					}
				}
			}
		});
		
		cancel_Btn.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				num1=0;
				num2=0;
				current_Operation=0;
				replace_Txt=true;
				is_Operator_Sum=false;
				is_Blocked=false;
				small_Txt.setText("");
				equation="";
				big_Txt.setText("0");
				is_Small_Txt=false;
				is_Cannot_Divide_By_Zero=false;
			}
		});
		
		sign_Btn.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				if(!big_Txt.getText().equals("0"))
				{
					if(is_Blocked)
					{
						small_Txt.setText(big_Txt.getText());
					}
						if(big_Txt.getText().substring(0,1).equals("-"))
							big_Txt.setText(big_Txt.getText().substring(1));
						else
							big_Txt.setText("-"+big_Txt.getText());
					
						
				}
				else
				{
					if(!is_Small_Txt)
						small_Txt.setText(equation="negate("+big_Txt.getText()+")");
					else
						small_Txt.setText(equation="negate("+small_Txt.getText()+")");
					is_Small_Txt=true;
					is_Negate=true;
				}
			}
		});
		
		dot_Btn.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				//big_Txt.setText(big_Txt.getText()+".");
			}
		});
		
		
	}
	
	void performOperation()
	{
		switch((int)current_Operation)
		{
			case 1:
				big_Txt.setText(new Integer(num1+num2).toString());
				break;
			case 2:
				big_Txt.setText(new Integer(num1-num2).toString());
				break;
			case 3:
				big_Txt.setText(new Integer(num1*num2).toString());
				break;
			case 4:
				try
				{
					big_Txt.setText(new Integer(num1/num2).toString());
				}
				catch(ArithmeticException e)
				{
					System.out.println("Dhananjay");
					big_Txt.setText("Cannot divide by zero");
					replace_Txt=true;
					is_Cannot_Divide_By_Zero=true;
				}
				break;
			default:
				System.out.println("Hello");
		}
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		
		if (!is_Cannot_Divide_By_Zero)
		{
			int i=Integer.parseInt(ae.getActionCommand());
			is_Blocked=false;
			if(replace_Txt)
			{
				big_Txt.setText(new Integer(i).toString());
				replace_Txt=false;
			}
			else
			{
				big_Txt.setText(big_Txt.getText() + new Integer(i).toString());
			}
		}
		else
		{
			int i=Integer.parseInt(ae.getActionCommand());
			num1=0;
			num2=0;
			current_Operation=0;
			replace_Txt=true;
			is_Operator_Sum=false;
			is_Blocked=false;
			small_Txt.setText("");
			equation="";
			big_Txt.setText(new Integer(i).toString());
			is_Small_Txt=false;
			is_Cannot_Divide_By_Zero=false;
		}
			
		System.out.println("Pressed");
	}
	
	public static void main(String args[])
	{
		new Calculator();
	}
} 
