import java.net.*;
import java.io.*;


class Server
{
	Server()
	{

	}

	public static void main(String args[]) throws Exception
	{
		ServerSocket serverSocket;
			serverSocket=new ServerSocket(8967);
			Socket s=serverSocket.accept();
		while(true)
		{
			
			InputStream in=s.getInputStream();
			OutputStream out=s.getOutputStream();
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			BufferedReader bin=new BufferedReader(new InputStreamReader(in));
			BufferedWriter bout=new BufferedWriter(new OutputStreamWriter(out));
			//System.out.println("I am Here");
			System.out.println(bin.readLine());
			//System.out.println("then here");
			String temp=br.readLine();
			temp=temp+"\n";
			bout.write(temp,0,temp.length());
			String temp1=br.readLine();
		}

	}
}