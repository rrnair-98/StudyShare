
class StringDemo 
{
	public static void main(String[] args) 
	{
		String s=new String("Hello");
		StringBuffer sb=new StringBuffer("Hello");
		System.out.println(s.equals(sb));
	}
}
