import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.*;
import javax.swing.event.*;
class NoBorder extends JFrame 
{
	ImageIcon map;
	JLabel image;
	MyTextField jtf=new MyTextField(10);

	NoBorder()
	{
		setLayout(new FlowLayout());
		add(jtf);
		setSize(500,500);
		setVisible(true);
	}

	public static void main(String args[])
	{
		NoBorder r=new NoBorder();
	}

	
}

class MyTextField extends JTextField //implements DocumentListener
{
	MyTextField(int siz)
	{
		super(siz);
		setOpaque(false);
		setBorder(BorderFactory.createEmptyBorder());
		//setBackground(new Color(0,0,0,0));
		//setForeground(new Color(0,0,225));
		//getDocument().addDocumentListener(this);
	}

	/*public void changedUpdate(DocumentEvent de){MyTextField.this.repaint();}
	public void insertUpdate(DocumentEvent de){MyTextField.this.repaint();}
	public void removeUpdate(DocumentEvent de){MyTextField.this.repaint();}

	public void paint(Graphics g)
	{
		super.paint(g);
		//this.setText(" ");
	}*/
}