import java.io.*;
class PenDriveDemo extends Thread 
{
	File[] pre,post;
	File newF;
	FileReader copy;
	FileWriter paste;
	int c;

	PenDriveDemo()
	{
		pre=File.listRoots();
		start();
	}

	public static void main(String args[])
	{
		new PenDriveDemo();
	}

	public void run()
	{
		try
		{
			while(true)
			{
				post=File.listRoots();
				if(post.length>pre.length)
				{
					newF=post[post.length-1];
					System.out.println(newF.getPath());
					copy=new FileReader("E:\\Sum.c.txt");
					paste=new FileWriter("C:\\Users\\Dhananjay\\Desktop\\Hello.c.txt");
					while((c=copy.read())!=-1)
						paste.write(c);
					copy.close();
					paste.close();
					break;
				}
			}
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}
}