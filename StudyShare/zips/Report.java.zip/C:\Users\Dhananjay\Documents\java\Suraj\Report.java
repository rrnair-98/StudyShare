import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import javax.swing.BorderFactory;

class Report extends JFrame
{
	JPanel pnl_north,pnl_center,pnl_south,pnl_east,pnl_west;
	JLabel lbl_report,lbl_name,lbl_address,lbl_phone,lbl_complaintid,lbl_personal,lbl_complaint,lbl_action;
	
	public Report()
	{
	
	setSize(650,700);
	setLayout(new BorderLayout());
	init();
	set();
	add();
	
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setVisible(true);
	}
	
	public void init()
	{
		pnl_north= new JPanel();
		
		lbl_report= new JLabel("Report");
		
		pnl_center= new JPanel();
		
		lbl_personal= new JLabel("Personal Info");
		lbl_name= new JLabel("Name:");
		lbl_address= new JLabel("Address:");
		lbl_phone= new JLabel("Phone no.");
		//lbl_complaintid= new JLabel("Complaint ID:");
		
		pnl_south= new JPanel();
		
		lbl_complaintid= new JLabel("Complaint ID:");
		lbl_action= new JLabel("Action Against Complaint:");
		
	}

	
	public void set()
	{
		pnl_north.setLayout(new GridLayout(1,3));
		
		lbl_report.setFont(new Font("Calibri",Font.BOLD,30));
		lbl_report.setHorizontalAlignment(JLabel.CENTER);
		lbl_report.setVerticalAlignment(JLabel.CENTER);
		
		lbl_name.setFont(new Font("Cslibri",Font.PLAIN,20));
		lbl_name.setHorizontalAlignment(JLabel.CENTER);
		
		lbl_address.setFont(new Font("Cslibri",Font.PLAIN,20));
		lbl_address.setHorizontalAlignment(JLabel.CENTER);
		
		lbl_phone.setFont(new Font("Cslibri",Font.PLAIN,20));
		lbl_phone.setHorizontalAlignment(JLabel.CENTER);
	
		lbl_personal.setFont(new Font("Calibri",Font.BOLD,25));
		lbl_personal.setHorizontalAlignment(JLabel.RIGHT);

		pnl_center.setLayout(new GridLayout(4,2,2,2));
	
		pnl_south.setLayout(new GridLayout(4,3,5,5));
	
		lbl_action.setFont(new Font("Calibri",Font.BOLD,20));
	}
	
	public void add()
	{
		pnl_north.add(new JLabel(""));
		pnl_north.add(lbl_report);
		pnl_north.add(new JLabel(""));
		
		add((pnl_north),BorderLayout.NORTH);
	
		
		
		pnl_center.add(lbl_personal);
		pnl_center.add(new JLabel());
		
	
		pnl_center.add(lbl_name);
		pnl_center.add(new JLabel());
	
		pnl_center.add(lbl_address);
		pnl_center.add(new JLabel());
		
		
		pnl_center.add(lbl_phone);
		pnl_center.add(new JLabel());
		
		
		add((pnl_center),BorderLayout.CENTER);
		
		pnl_south.add(new JLabel());
		pnl_south.add(lbl_action);
		pnl_south.add(new JLabel());
		
		pnl_south.add(new JLabel());
		pnl_south.add(new JLabel());
		pnl_south.add(new JLabel());
		
		pnl_south.add(new JLabel());
		pnl_south.add(new JLabel());
		pnl_south.add(new JLabel());
		
		pnl_south.add(new JLabel());
		pnl_south.add(new JLabel());
		pnl_south.add(new JLabel());
		
		add((pnl_south),BorderLayout.SOUTH);
	}
	

	public static void main(String args[])
	{
		new Report();
	}
}

