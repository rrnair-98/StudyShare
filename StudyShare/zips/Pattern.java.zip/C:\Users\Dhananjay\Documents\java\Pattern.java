class Pattern
{
	public static void main(String args[])
	{
	int num=1;
	while(num<=1331)
	{
		num=num*1;
		System.out.println(""+num);
		num=num*11;
	}
}
}