import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
class MyDialog extends JFrame 
{
	//JProgressBar b;
	JColorChooser jc;
	JPanel j;
	MyDialog()
	{
				j=new JPanel();
		add(j);
		j.add(jc=new JColorChooser());
		jc.setDragEnabled(true);
		//b.setValue(10);
		j.setBorder(new StrokeBorder(new BasicStroke(10,BasicStroke.CAP_ROUND,BasicStroke.JOIN_BEVEL)));
		j.setSize(100,100);
		j.setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//setBorder(new MatteBorder(new ImageIcon("tt.png")));
		setSize(100,100);
		setVisible(true);
	
	}
	public static void main(String[] args) 
	{
		new MyDialog();	
	}
}
