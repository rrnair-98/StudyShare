package packageDemo.p1;
import packageDemo.*;

public class  B
{

	public void show()
	{
		System.out.println("Inside B's show");
		new A().callPratik();
	}
}