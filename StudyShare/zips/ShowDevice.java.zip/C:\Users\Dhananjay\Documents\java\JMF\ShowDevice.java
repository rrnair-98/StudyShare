import javax.media.*;
import javax.media.format.*;
import java.util.*;
import java.io.*;
import com.lti.civil.*;
import java.lang.reflect.*;
//"C:\\Users\\Dhananjay\\Videos\\Any Video Converter\\MP2\\03 - Aadha Ishq_001"
class ShowDevice
{
	
	CaptureDeviceManager manager;
	Vector devices;
	javax.media.CaptureDeviceInfo d1;
	
	ShowDevice()
	{
		Vector v=CaptureDeviceManager.getDeviceList(new RGBFormat());
		System.out.println("No here"+v.size());
		try
		{
			System.out.println((javax.media.CaptureDeviceInfo)v.firstElement());
		}
		catch(Exception e){System.out.println(e);}
	}
	
	public static void main(String args[]) throws Exception
	{
		new ShowDevice();
	}
}