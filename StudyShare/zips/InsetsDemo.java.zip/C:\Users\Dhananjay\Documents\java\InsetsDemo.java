import javax.swing.*;
import java.awt.*;
class InsetsDemo extends JFrame
{
	JPanel jp;
	InsetsDemo()
	{
		jp=new JPanel(){
			public Insets getInsets()
			{
				return new Insets(60,60,60,60);
			}
		};
		jp.setBackground(new Color(0,0,111));
		setBackground(new Color(111,111,111));
		//
		jp.setLayout(new BorderLayout());
		//jp.add(new Button("AREA"));
		add(jp,BorderLayout.CENTER);
		add(new JPanel(),BorderLayout.NORTH);
		setSize(500,500);
		setVisible(true);
	}

	public static void main(String args[])
	{
		new InsetsDemo();
	}
}