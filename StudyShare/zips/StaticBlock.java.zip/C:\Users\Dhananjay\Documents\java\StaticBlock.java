import java.util.*;

class StaticBlock{
	
	public static void main(String args[]){
		System.out.println(Demo.d);
		Vector v=new Vector(10);
		v.add(new Object(10));
	}
}


class Demo{
	static int d;
	static{
		//Vector v=new Vector(10);
		//v.add(new Object());
		System.out.println("Inside Static Block");
	}
	
}