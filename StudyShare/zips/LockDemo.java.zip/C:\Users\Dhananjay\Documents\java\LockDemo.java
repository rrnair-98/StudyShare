import java.awt.*;
import java.awt.event.*;
class LockDemo
{
	LockDemo()
	{
		try
		{
			while(true)
			Toolkit.getDefaultToolkit().beep();
	    }
		catch(Exception e)
		{
		}
	}
	public static void main(String args[])
	{
		new LockDemo();
	}
}





