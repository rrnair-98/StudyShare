class PatternA
{
	public static void main(String[] args) 
	{
		int i,j;
		for(i=0;i<4;i++)
		{
			System.out.println(" ");
			for(j=2;j<=4;j++)
			{
				for( int k=2;k<=4;k--)
				if(i==j)
				{
					System.out.print("*");
				}
				else if(i+k==2)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
				
			}
		}
	}
}
