import java.awt.*;
import java.awt.event.*;
class AgreementUI extends Frame implements ItemListener,ActionListener
{
	AgreementUI()
	{
		super("DirectX");
		setSize(500,500);
		setLayout(new BorderLayout());

		Panel p1= new Panel();
		Panel p2= new Panel();
		Panel p3= new Panel();
		Panel p4= new Panel();
		Panel p5= new Panel();

		Label l1= new Label("Welcome to the setup for DirectX ");
		l1.setFont(new Font("SansSerif",Font.BOLD,20));

		String str= "MICROSOFT SOFTWARE LICENCE TERMS\n" 
		+ "MICROSOFT DIRECTX END USER RUNTIME\n" 
			+ "These license terns are an agreement between Microsoft\n" 
			+ "Corporation(or based on where you live, one of its\n"
			+  "affiliates) and you. Please read them. They apply to\n" 
			+	"the software named above, which includes the media on\n"
			+  "which you recieved it, if any.. The terms also apply to any\n"
			+ "Microsoft.\n"
			+"*updates.";
		
		Label l2= new Label("The DirectX setup wizard guides you through installation of");
		Label l3= new Label("DirectX runtime components. Please read the following");
		Label l4= new Label("licence agreement. Press the PAGE DOWN key to see the rest");
		Label l5= new Label("of the agreement. You must accept the agreement to continue");
		Label l6= new Label("the setup.");
	
		
		
		TextArea t1= new TextArea(str,60,50);
		t1.setEditable(false);
		//t1.setPreferredSize(new Dimension(100,100));
		

		Checkbox c1,c2;
		CheckboxGroup cg= new CheckboxGroup();

		c1= new Checkbox("I accept the agreement",cg,false);
		c2= new Checkbox("I don't accept the agreement",cg,false);
		c1.addItemListener(this);
		c2.addItemListener(this);
		
		add((p1),BorderLayout.CENTER);
		

		p1.setLayout(new GridLayout(5,1));
		p3.setLayout(new GridLayout(5,1));

		p1.add(l1);
		p1.add(p3);
		p1.add(p2);
		p1.add(p4);
		p1.add(p5);

		
		p2.setLayout(new GridLayout(1,1));
		p2.add(t1);

		
		p3.add(l2);
		p3.add(l3);
		p3.add(l4);
		p3.add(l5);
		p3.add(l6);

		p4.setLayout(new GridLayout(3,1));
		p4.add(c1);
		p4.add(c2);

		
		Label l7=new Label(" ");
		Button b1= new Button("< Back");
		Button b2= new Button("Next >");
		Button b3= new Button("Cancel");

		b1.addActionListener(this);
		b2.addActionListener(this);

		//b2.setVisible(false);
		p5.setLayout(new FlowLayout(FlowLayout.RIGHT));
		p5.add(b1);
		p5.add(b2);
		p5.add(l7);
		p5.add(b3);
		
		addWindowListener(new MyAdapter(this));
		setResizable(false);
		setVisible(true);


	}
	
	public void actionPerformed(ActionEvent ae)
	{
		/*if(ae.getSource==b3)
		{
			dispose();
		}*/
	}
	
	public void itemStateChanged(ItemEvent ie)
	{
		//c1.getState();
		
	}

	public void paint(Graphics g)
	{
		
		/*if(q1==true)
		{
			b2.setVisible(true);
		}*/
	}
	
	public Insets getInsets()
	{
		return new Insets(40,40,10,40);
	}
	
	public static void main(String args[])
	{
		AgreementUI x1= new AgreementUI();
	}
}
class MyAdapter extends WindowAdapter
{
	AgreementUI x1;
	MyAdapter(AgreementUI x2)
	{
		x1=x2;
	}
	public void windowClosing(WindowEvent we)
	{
		x1.dispose();
	}
}