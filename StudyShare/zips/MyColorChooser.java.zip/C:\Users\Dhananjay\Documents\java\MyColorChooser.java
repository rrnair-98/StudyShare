import java.awt.*;
import javax.swing.*;

class MyJColorChooser extends JColorChooser 
{
	public static void main(String args[])
	{
		new MyJColorChooser().show();
	}
}