import java.awt.*;
class AwtDemo extends Frame
{
	Graphics g;
	public static void main(String args[])
	{
		new AwtDemo();
	}
	AwtDemo()
	{
		setVisible(true);
		g=getGraphics();
		if(g!=null)
		{
			System.out.println("Dhananjay");
			paint(g);
		}
		setSize(100,100);
		
	}
	public void paint(Graphics g)
	{
		g.drawString("Dhananjay",100,100);
	}
}