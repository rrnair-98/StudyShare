class Outer
{
	Inner obj=new Inner();
	int ov;
	void showO()
	{
		System.out.println("INSIDE OUTER");
	}
	class Inner
	{
		int iv; 
		void showI()
		{
			System.out.println("INSIDE INNER");
			showO();
		}
	}
}
class InnerOuter
{
	public static void main(String args[])
	{
		Outer o=new Outer();
		o.obj.showI();
	}
}