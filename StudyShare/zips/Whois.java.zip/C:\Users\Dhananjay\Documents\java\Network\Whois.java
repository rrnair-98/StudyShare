import java.io.*;
import java.net.*;
class Whois
{
	Socket s;
	int c;
	public static void main(String args[])
	{
		int c;
		try (Socket s=new Socket("google.com",80))
		{
				InputStream is=s.getInputStream();
				OutputStream os=s.getOutputStream();
				String str="studylinkclasses.com";
				//os.write(str.getBytes());
				while((c=is.read())!=-1)
				{
					System.out.println((char)c);
				}
		}
		catch(Exception e)
		{
			System.out.println("OOps Exception "+e);
		}
	}
}