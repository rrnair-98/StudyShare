import javax.swing.*;
import java.awt.event.*;
import java.awt.*;


class Goods{
	Sync frame;
	int count=0;
	Goods(Sync ref)
	{
		frame=ref;
	}
	
	synchronized void produce(int count){
		this.count+=count;
		frame.lblCount.setText(new Integer(this.count).toString());
		System.out.println("Total Goods After produce():"+this.count);
		notifyAll();
	}
	
	synchronized void consume(int count){
		while(this.count<count){
			try{
				System.out.println("Wating");
					wait();
			}
			catch(Exception e){System.out.println(e);}
		}
		this.count-=count;
		frame.lblCount.setText(new Integer(this.count).toString());
		System.out.println("Total Goods After consume():"+this.count);
	}
	
}

class ConsumeThread implements Runnable{
	
	Thread t;
	Goods obj;
	int count;
	
	ConsumeThread(Goods obj,int count){
		this.obj=obj;
		this.count=count;
		t=new Thread(this);
		t.start();
	}
	
	public void run(){
			obj.consume(count);
	}
}


class ProduceThread implements Runnable{
	
	Thread t;
	Goods obj;
	int count;
	
	ProduceThread(Goods obj,int count){
		this.count=count;
		this.obj=obj;
		t=new Thread(this);
		t.start();
	}
	
	public void run(){
			obj.produce(count);
	}
}  


class Sync extends JFrame implements ActionListener{
	
	JButton produce=new JButton("Produce");
	JButton consume=new JButton("Consume");
	JLabel lblCount=new JLabel("0");
	Goods g=new Goods(this);
	Sync(){
		produce.addActionListener(this);
		consume.addActionListener(this);
		add(produce,BorderLayout.EAST);
		add(consume,BorderLayout.WEST);
		add(lblCount,BorderLayout.CENTER);
		setSize(100,100);
		setVisible(true);
	}
	
	public static void main(String args[]){
		new Sync();	
	}
	
	public void actionPerformed(ActionEvent ae){
		if(ae.getSource()==produce)
			new ProduceThread(g,1);
		else
			new ConsumeThread(g,1);
	}
}