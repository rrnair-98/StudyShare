import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class BTextField extends JFrame
{
	BTextField()
	{
		addMouseMotionListener(new My(this));
		add(new JLabel("Hello"));
		setSize(100,100);
		setVisible(true);
	}
	public static void main(String args[])
	{
		new BTextField();
	}
}

class My extends MouseMotionAdapter
{
	BTextField ref;
	My(BTextField obj)
	{
		ref=obj;
	}
	
	public void mouseEntered(MouseEvent me)
	{
		ref.add(new TextField());
		ref.setSize(100,99);
		
	}
	public void mouseExited(MouseEvent me)
	{
		ref.add(new JLabel("Hello"));
		ref.setSize(100,99);
	}
}