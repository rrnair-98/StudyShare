import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.sql.*;

public class dbfetch extends JFrame implements ActionListener,FocusListener
{
	JTextField ta=new JTextField(10);
	JTextField ta1=new JTextField(10);
	JLabel name= new JLabel("Name");
	JLabel number=new JLabel("Phone Number");
	JButton confirm1=new JButton("Confirm1");
	JButton confirm2=new JButton("Confirm2");
	public static String nm="",numb="";
	dbfetch()
	{
		
		setSize(300,300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ta.addFocusListener(this);
		ta1.addFocusListener(this);
		confirm1.addActionListener(this);
		confirm2.addActionListener(this);
		setVisible(true);
		setLayout(new GridLayout(3,3));
		add(name);
		add(number);
		add(ta);
		add(ta1);
		add(confirm1);
		add(confirm2);
	}
	public void focusGained(FocusEvent fe)
	{
		
	}

	public void focusLost(FocusEvent fe)
	{
		
	}

	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==confirm1)
		{ 
			try
			{
				confirm2.setEnabled(false);
				if(ta.getText().length()<1)
				{
					System.out.println("in if");
					JOptionPane.showMessageDialog(this,"Oops! you forgot your name","Register",JOptionPane.INFORMATION_MESSAGE);
				}
				else
				{
					nm=ta.getText();
					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					//This forces the driver to register itself,so that java knows how to handle those database
					//connection strings
					Connection con=DriverManager.getConnection("jdbc:odbc:cust");
					PreparedStatement ps=con.prepareStatement("Select Number from Customer where Name= ?");
					ps.setString(1,ta.getText());
					ResultSet rs=ps.executeQuery();
					System.out.println("bas bas");
					while(rs.next())
					{
						ta1.setText(rs.getString("Number"));
					}
					confirm2.setEnabled(true);
				}
			}
			catch(Exception e)
			{

			}
		}
		if(ae.getSource()==confirm2)
		{
			try
			{
				nm=ta.getText();
				numb=ta1.getText();
				System.out.println(nm);
				System.out.println(numb);
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				//This forces the driver to register itself,so that java knows how to handle those database
				//connection strings
				Connection con=DriverManager.getConnection("jdbc:odbc:cust");
				PreparedStatement ps=con.prepareStatement("Insert into customer values(?,?)");
				ps.setString(1,nm);
				ps.setString(2,numb);
				ps.executeUpdate();
			}			
			catch(Exception e)
			{
			}
		}	
	}
	public static void main(String args[])throws Exception
	{
		new dbfetch();
	}
}

