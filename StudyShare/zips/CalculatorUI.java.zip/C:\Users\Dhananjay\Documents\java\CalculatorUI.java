import javax.swing.*;
import java.awt.*;
class Calculator extends JFrame
{
	JMenuBar menuBar;
	Calculator()
	{
		makeMenu();
		setJMenuBar(menuBar);
		add(new UI(),BorderLayout.NORTH);
		setIconImage(new ImageIcon("Logo.png").getImage());
		setTitle("Calculator");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setSize(650,700);
		setVisible(true);
	}

	void makeMenu()
	{
		menuBar=new JMenuBar();
		JMenu view,edit,help;
		view=new JMenu("View");
		edit=new JMenu("Edit");
		help=new JMenu("Help");
		menuBar.add(view);
		menuBar.add(edit);
		menuBar.add(help);
	}

	public static void main(String args[])
	{
		new Calculator();
	}
}

class UI extends JPanel
{
	JTextField small,large;
	GridBagConstraints gbc;
	GridBagLayout gridBag;
	JButton mc,mr,ms,mp,mm;

	UI()
	{
		initalizeAll();
		constraintAll();
		setLayout(gridBag);
	}

	void initalizeAll()
	{
		gridBag=new GridBagLayout();
		gbc=new GridBagConstraints();
		small=new JTextField(31);
		large=new JTextField(31);
		mc=new JButton("MC");
		mr=new JButton("MR");
		ms=new JButton("MS");
		mp=new JButton("M+");
		mm=new JButton("M-");
	}
	
	void constraintAll()
	{
		gbc.gridwidth=GridBagConstraints.REMAINDER;
		make(small);
		make(large);
		gbc.gridwidth=GridBagConstraints.RELATIVE;
		make(mc);
		make(mr);
		//make(ms);
		//m/ake(mp);
		//gbc.gridwidth=GridBagConstraints.REMAINDER;
		//make(mm);
		//make(new JButton("GOOD"));

	}

	void make(Component c)
	{
		gridBag.setConstraints(c,gbc);
        add(c);
	}
	
	public Insets getInsets()
	{
		return new Insets(10,5,5,5);
	}

}