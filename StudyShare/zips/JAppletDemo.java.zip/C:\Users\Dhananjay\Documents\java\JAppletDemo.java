import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.applet.*;
//<applet code="JAppletDemo" width="400" height="400"></applet>
public class JAppletDemo extends JApplet implements KeyListener
{
	KeyboardFocusManager kfm;
	String msg="Dhananjay";
	public void init()
	{
			System.out.println("Exception");
		this.requestFocus();

		//kfm=KeyboardFocusManager.getCurrentKeyboardFocusManager();
	
		getGlassPane().addKeyListener(new KeyAdapter(){
		public void keyPressed(KeyEvent ke){
			System.out.println("random");
		}
			
		});
		getRootPane().getContentPane().addMouseListener(new MouseAdapter(){
		public void mouseClicked(MouseEvent me){
			System.out.println("asdasd");	
		}
		});
			//Thread.sleep(1000);
			System.out.println("GOing to excute");
	}

	public void keyTyped(KeyEvent ke)
	{
		System.out.println("executed");
		msg+=ke.getKeyChar();
		repaint();
	}

	public void paint(Graphics g)
	{
		g.drawString(msg,100,100);
	}
	 
	public void keyReleased(KeyEvent ke){System.out.println("executed");}
	public void keyPressed(KeyEvent ke){System.out.println("executed");}
}
