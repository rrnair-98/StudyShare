import java.net.*;
import java.io.*;

class  Client
{
	Client()
	{
	}

	public static void main(String[] args) throws Exception
	{
		int c;
		Socket s=new Socket("127.0.0.1",8967);
		while(true)
		{
			
			InputStream in=s.getInputStream();
			OutputStream out=s.getOutputStream();
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

			BufferedReader bin=new BufferedReader(new InputStreamReader(in));
			BufferedWriter bout=new BufferedWriter(new OutputStreamWriter(out));
			String temp=br.readLine();
			temp=temp+"\n";
			System.out.println(temp);
			//System.out.println("I am here");
			bout.write(temp,0,temp.length());
			//System.out.println("then here");
			System.out.println(bin.readLine());
		}
		
	}
}
