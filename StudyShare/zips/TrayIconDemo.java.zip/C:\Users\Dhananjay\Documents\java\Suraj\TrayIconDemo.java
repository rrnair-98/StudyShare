//import java.awt.SystemTray;
//import java.awt.TrayIcon;
import java.awt.*;

public class TrayIconDemo
{
SystemTray systemtray
	public static void main (String args[])
	{
			if(SystemTray.isSupported())
			{
				System.out.println("System tray is supported");
			}
	
		= SystemTray.getSystemTray();
		TrayIcon trayicon= new TrayIcon(Image ,"Suraj Kakad",PopupMenu );

		Image img= ToolKit.getDefaultToolKit().getImage()
	}
}
