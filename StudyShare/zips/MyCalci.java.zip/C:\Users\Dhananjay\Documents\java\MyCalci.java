import java.awt.*;
import java.awt.event.*;
class MyTextField 
{
	TextField dis=new TextField();
	MyTextField()
	{
		dis.setEditable(false);
	}
	void show(String s)
	{
		dis.setText(s);
	}
}
class MyCalci extends Frame 
{
	MyTextField t1;
	Button equ;
	Operators east;
	Operators west;
	NumInput ni; 
	MyCalci()
	{
		//Output 
			t1=new MyTextField();
			add(t1.dis,BorderLayout.NORTH);
			t1.dis.setBackground(Color.pink);
		//Input
			//Operands
				ni=new NumInput(t1);
				add(ni,BorderLayout.CENTER);
			//Operators
				//East
					east=new Operators("+","-");
					add(east,BorderLayout.EAST);
				//West
					west=new Operators("/","%");
					add(west,BorderLayout.WEST);
				//EQU
					equ=new Button("=");
					add(equ,BorderLayout.SOUTH);
		//INIT
			setBackground(new Color(200,200,200));
			setSize(250,180);
			setVisible(true);
			addWindowListener(new WindowAdapter()
			{
					public void windowClosing(WindowEvent we)
					{
						System.exit(0);
					}
			});
	}
	public static void main(String[] args) 
	{
		new MyCalci();
		System.out.println("Hello World!");
	}
}
class NumInput extends Panel implements ActionListener
{
	String digit;
	Button n;
	MyTextField my;
	NumInput(MyTextField my1)
	{
		my=my1;
		setLayout(new GridLayout(3,4,2,2));
		add(n=new Button("1"));
		n.addActionListener(this);
		add(n=new Button("2"));
		n.addActionListener(this);	
		add(n=new Button("3"));
		n.addActionListener(this);
		add(n=new Button("4"));
		n.addActionListener(this);
		add(n=new Button("5"));
		n.addActionListener(this);
		add(n=new Button("6"));
		n.addActionListener(this);
		add(n=new Button("7"));
		n.addActionListener(this);
		add(n=new Button("8"));
		n.addActionListener(this);
		add(n=new Button("9"));
		n.addActionListener(this);
		add(n=new Button("0"));
		n.addActionListener(this);
		add(n=new Button("<-"));
		n.addActionListener(this);
		add(n=new Button("CE"));
		n.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae)
	{
		n=(Button)ae.getSource();
		my.dis.setText(n.getLabel());
	}
}
class Operators extends Panel
{
	Operators(String op1,String op2)
	{
		add(new Button(op1));
		add(new Button(op2));
	}
}
