package TagBrothers;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import TagBrothers.controls.*;

public class MessageAllPanel extends JPanel
{
	JLabel lbl_Message_All;
	JTextArea txt_Message_All;
	JButton send;
	
	public MessageAllPanel()
	{
		setLayout(new BorderLayout());
		initializeAll();
		addAll();
	}
	
	private void initializeAll()
	{
		lbl_Message_All=new JLabel("Message for all..");
		txt_Message_All=new JTextArea();
		send=new JButton("Send");
	}
	
	private void addAll()
	{
		add(lbl_Message_All,BorderLayout.NORTH);
		add(txt_Message_All,BorderLayout.CENTER);
		add(send,BorderLayout.SOUTH);
	}
}