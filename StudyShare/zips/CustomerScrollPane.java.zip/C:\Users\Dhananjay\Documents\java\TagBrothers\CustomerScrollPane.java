package TagBrothers;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;

public class CustomerScrollPane extends JScrollPane
{
	JPanel innerPanel;
	public CustomerScrollPane()
	{
		initializeAll();
		addAll();
	}
	
	public void addAll()
	{
		innerPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		getViewport().add(innerPanel);
	}
	
	public void initializeAll()
	{
		innerPanel=new JPanel();
	}
}