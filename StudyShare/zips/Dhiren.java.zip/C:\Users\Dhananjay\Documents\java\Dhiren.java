import java.awt.*;
import javax.swing.*;
import java.applet.*;
//<applet code="Dhiren" height="100" width="100"></applet>
public class Dhiren extends Applet
{
	JFrame jf=new JFrame();;
	JComboBox jc;
	String arr[]={"Dhananjay","Sanjay","Ghumare"};
	
	public void init()
	{	
	 jc=new JComboBox(arr);
	 jf.setSize(100,100);
	 jf.setVisible(true);
	 add(jc);
	}
	
	public void paint(Graphics g)
	{
		
		System.out.println("Dhananjay");
	}
}