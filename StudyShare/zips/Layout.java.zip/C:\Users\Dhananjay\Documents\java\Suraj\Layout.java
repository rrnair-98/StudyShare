import java.awt.*;
class Layout extends Frame 
{
	Layout()
	{
		super("Hardwell");
		Panel p1= new Panel();
		Panel p2= new Panel();
		Panel p3= new Panel();
		Panel p4= new Panel();
		Panel p5= new Panel();
		Panel p6= new Panel();

		Label l1=new Label("Last Name: ");
		Label l2=new Label("First name: ");
		Label l3=new Label("Middle Name: ");
		
		Label l4= new Label("Date of Birth: ");
		
		Label l5= new Label("    ");
		Label l6= new Label("    ");
		Label l7= new Label("    ");
		Label l8= new Label("    ");
		
		Label l9= new Label("DD: ");
		Label l10= new Label("MM: ");
		Label l11= new Label("YY: ");




		TextField t1= new TextField(20);
		TextField t2= new TextField(20);
		TextField t3= new TextField(20);

		TextField t4= new TextField(20);
		
		TextField t5= new TextField(10);
		TextField t6= new TextField(10);
		TextField t7= new TextField(10);

		/*Label l4=new Label();
		Label l5=new Label();
		Label l6=new Label();*/		
		
		setSize(500,500);
		setLayout(new BorderLayout());
		setBackground(Color.LIGHT_GRAY);
		add((p1),BorderLayout.NORTH);
		
		
		p1.setLayout(new GridLayout(2,3,10,2));
		p2.setLayout(new FlowLayout(FlowLayout.LEFT));
		//p3.setLayout(new GridLayout(2,3));
		p3.setLayout(new FlowLayout(FlowLayout.LEFT));
		p4.setLayout(new FlowLayout(FlowLayout.LEFT));
		p5.setLayout(new GridLayout(7,3));
		
		p1.add(l1);
		p1.add(l2);
		p1.add(l3);
		p1.add(t1);
		p1.add(t2);
		p1.add(t3);

		add(p2);
		p2.add(l4);
		p2.add(l8);

		p2.add(p3);
		p3.add(l5);
		p3.add(l6);
		p3.add(l7);
		p3.add(l8);

		p3.add(p4);
		p4.add((l9),FlowLayout.LEFT);
		p4.add((l10),FlowLayout.CENTER);
		p4.add((l11),FlowLayout.RIGHT);

		add((p5),BorderLayout.NORTH);
		p5.add(p1);
		p5.add(p2);
		p5.add(p3);
		p5.add(p4);
		p5.add(t5);
		p5.add(t6);
		p5.add(t7);
		
		//p1.setLayout(BorderLayout.NORTH);
		//addWindowListener(new MyAdapter(this));
		setVisible(true);
	}
	public static void main(String args[])
	{
		Layout l1= new Layout();
	}
}
/*class MyAdapter extends WindowAdapter
{
	Layout f;
	MyAdapter(Layout ref)
	{
		f=ref;
	}
	public void windowClosing(WindowEvent we)
	{
		f.dispose();
	}
}*/