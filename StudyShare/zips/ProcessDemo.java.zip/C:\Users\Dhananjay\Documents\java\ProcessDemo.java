import java.io.*;

class ProcessDemo{
	public static void main(String args[])throws Exception{
		Process p = new ProcessBuilder("java","SubProcess").start();
		InputStream os=p.getErrorStream();
		
		int i;
		while((i=os.read())!=-1)
			System.out.print((char)i);
	}
}

