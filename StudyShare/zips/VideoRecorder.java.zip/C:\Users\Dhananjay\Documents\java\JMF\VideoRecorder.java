import java.util.Vector;
import javax.media.*;
import javax.media.format.AudioFormat;
import javax.media.format.VideoFormat;
import javax.media.protocol.DataSource;
import javax.media.CaptureDeviceInfo;
import javax.media.format.YUVFormat;
import javax.media.protocol.FileTypeDescriptor;

public class VideoRecorder {

    static VideoFormat videoFormat;
    static CaptureDeviceInfo videoDevice;

    public static void main(String[] args) 
	{
		try {
        Vector deviceList = CaptureDeviceManager.getDeviceList(new YUVFormat());
		System.out.println(deviceList.size());
		videoDevice=(CaptureDeviceInfo)deviceList.firstElement();
		System.out.println(videoDevice.getName());
       
	   {
		   System.out.println("formats supported :");
		   Format form[]=videoDevice.getFormats();
		   for(int i=0;i<form.length;i++)
		   {
				System.out.println(form[i]);
		   }
	   }
        //create data sources
        DataSource videoDataSource = Manager.createDataSource(videoDevice.getLocator());

      System.out.println(videoDataSource);

            Format [] fm=new Format[1];
			fm[0]=new YUVFormat();

        //output type
            FileTypeDescriptor outputType=new FileTypeDescriptor(FileTypeDescriptor.QUICKTIME);
			System.out.println(outputType);

        //settingup Processor
            ProcessorModel processorModel=new ProcessorModel(videoDataSource,fm,outputType);
            Processor processor=Manager.createRealizedProcessor(processorModel);
			System.out.println("Hello");

        //settingup sink
            DataSource outputDataSource=processor.getDataOutput();
            MediaLocator destination=new MediaLocator("file:.\\HI.mov");
            DataSink dataSink=Manager.createDataSink(outputDataSource, destination);
            dataSink.open();

            //start sink + processor
            dataSink.start();
            processor.start();
			System.out.println("Started");

            Thread.sleep(4000);
			
			System.out.println("Stopped");
            dataSink.close();
            processor.stop();
            processor.close();

    } catch (Exception ex) {
        System.out.println(ex);

    }
	}
}