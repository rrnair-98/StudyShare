import java.net.*;

class InetAddressDemo
{
	InetAddress obj[];

	InetAddressDemo()
	{
		try
		{
			obj=InetAddress.getAllByName("www.google.us");
			for (int i=0;i<obj.length;i++ )
			{
				System.out.println(obj[i].getHostName());	
				System.out.println(obj[i].getHostAddress());
			}
		}
		catch (Exception e)
		{
		}
	}

	public static void main(String args[])
	{
		new InetAddressDemo();
	}
}
