import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;

class GridBagDemo extends JFrame
{
	GridBagConstraints gbc=new GridBagConstraints();
	Button b=new Button("Yes");
	GridBagLayout gbl;
	GridBagDemo()
	{
		gbc.gridwidth=4	;
		gbc.gridheight=4;
		gbc.weightx=11;
		gbc.weighty=12;
		setLayout(gbl=new GridBagLayout());
		add(b);
		gbl.setConstraints(b,gbc);
		add(new Button("No"));
		add(new Button("No"));
		add(new Button("No"));
		add(new Button("No"));
		add(new Button("No"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	public static void main(String args[])
	{
		new GridBagDemo();
	}
}