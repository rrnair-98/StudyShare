class Space
{
	public static void main(String args[])
	{
		int i,j,k;
		for(i=0;i<=5;i++)
		{
			for(j=0;j<=i;j++)
			{
				System.out.print("_");
			}
			System.out.println();	
		}	
			for(k=0;k<=5;k++)
			{
			
			for(j=2;j<=5;j++)
			{
				System.out.print("*");
			}
		}
	}
}