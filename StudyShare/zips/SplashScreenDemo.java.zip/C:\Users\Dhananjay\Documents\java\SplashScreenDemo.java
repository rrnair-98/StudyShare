import java.net.*;
import java.awt.*;
class SplashScreenDemo  
{
	SplashScreen f;
	SplashScreenDemo()
	{
		try
		{
			f=SplashScreen.getSplashScreen();
		f.setImageURL(new URL("http://C:\Users\Dhananjay\Documents\java/tt.png"));
		}
		catch (Exception e)
		{
			System.out.println("Hello World!");
		}
	}
	public static void main(String[] args) 
	{
		new SplashScreenDemo();
		
	}
}
