class Example
{
	public static void main(String arsg[])
	{
		System.out.println("Sucess");
	}
}