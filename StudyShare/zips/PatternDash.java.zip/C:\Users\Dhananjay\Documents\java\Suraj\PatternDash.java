class PatternDash
{
	public static void main(String args[])
	{
		int i,j;
		for(i=0;i<=5;i++)
		{
			System.out.println(" ");
			for(j=0;j<=5;j++)
			{
				if(j==0 || j==5)
				{
					System.out.print("|");
				}
				else if(i==2)
				{
					System.out.print("-");	
				}
				else
				{
					System.out.print(" ");
				}
			}
		}
	}
}