package TagBrothers.controls;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;

public abstract class ValidatedTextField extends JTextField implements KeyListener
{
	public ValidatedTextField()
	{
			addKeyListener(this);
	}
	
	abstract public boolean validateTextField();
	
	public void keyPressed(KeyEvent ke){}
	
	public void keyReleased(KeyEvent ke){}
	
	public void keyTyped(KeyEvent ke)
	{
		if(Character.isDigit(ke.getKeyChar()))
			ke.consume();
		//(ke.getKeyCode()==KeyEvent.VK_BACK_SPACE)
	}	
}